#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 18 14:31:09 2019

@author: chaoqiang

Copyright (C) 2019,
CFA Lab and Dept. of Biomedical Engineering, National University of Singapore. 
All rights reserved.
"""
import os
import nibabel as nib
import numpy as np
from scipy import ndimage 
import h5py
from sklearn.utils import shuffle
#import .read_filelist as
from lib import read_filelist as rflist
import math
import random
#import tensorflow as tf
from sklearn import metrics
from sklearn import metrics
import matplotlib.pyplot as plt
import pandas as pd
import gc
#DATADIR = r"G:/BaiduNetdiskDownload/ADNI_3DDATA/ADNI_3Ddata/"
#DATADIR = '/data/ADNI_3Ddata'
np.set_printoptions(threshold = 1e6)

def adni_get_subset_3D2D_slices_for_data(listname, label1, label2, imagepath, slicesindex=64, readnum=-1, training=1, direction=0):
    filepaths, Label, Age, Gender, study, SubjID, waveid, subjtype = rflist._read_all_filelist(listname, ',')

    if readnum <= 0:
        readnum = len(Label)

    if readnum < len(Label):
        filepaths = filepaths[0:readnum]
        Label = Label[0:readnum]
        Age = Age[0:readnum]
        Gender = Gender[0:readnum]
        study = study[0:readnum]
        SubjID = SubjID[0:readnum]
        waveid = waveid[0:readnum]
        subjtype = subjtype[0:readnum]
    #print("subjtype:", subjtype)
    #os.exit()
    print("in Label.shape:", Label.shape)
    select_index = []
    for i in range(len(Label)):
        select_index.append(i)

    base_index = [i for i, aa in enumerate(Label) if aa < label1]

    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)

    filepaths = np.array(filepaths)
    Label_s = Label[select_index]
    Age_s = Age[select_index]
    Gender_s = Gender[select_index]
    filepaths_s = filepaths[select_index]

    thick_s = []
    edge = 32


    waveid = np.array(waveid)
    SubjID = np.array(SubjID)
    subjtype = np.array(subjtype)

    waveid_s = waveid[select_index]
    SubjID_s = SubjID[select_index]
    subjtype_s = subjtype[select_index]

    waveid_s = np.array(waveid_s)
    SubjID_s = np.array(SubjID_s)
    subjtype_s = np.array(subjtype_s)

    thick_s = np.array(thick_s)
    #    thick_s = np.expand_dims(thick_s, axis=3)

    if len(base_index) > 0:
        thick_base = []  # thickdata[base_index]
        Age_base = Age[base_index]
        Gender_base = Gender[base_index]
    else:
        thick_base = []
        Age_base = []
        Gender_base = []
    thick_base = np.array(thick_base)
    Label_s[Label_s == label1] = 0
    Label_s[Label_s == label2] = 1
    print("Label_s.shape:", len(Label_s))
    Age_base = np.array(Age_base)
    Gender_base = np.array(Gender_base)

    return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index,  thick_s, Age_s, Gender_s, thick_base, Age_base, Gender_base, filepaths_s, waveid_s, SubjID_s, subjtype_s



def get_results(filename, test=1):
    group = "cn_ad"

    #index, Idx, slice, Actual, Predicted
    index, Idx, slice, Actual, Predicted = get_data_csv(filename)

    print("in get_result")
    print("index.shape", index.shape)
    print("Idx.shape", Idx.shape)

    print("slice.shape", slice.shape)
    print("Actual.shape", Actual.shape)
    print("Predicted.shape", Predicted.shape)



    #print("dir_slice:", dir_slice)
    Actual = np.array(Actual)
    prevalence = np.sum(Actual)/Actual.shape[0]
    acc_test, fscore_test, sensitivity_test, specificity_test, precision_test, ppv_test, npv_test, gmean_test = top_k_error(Actual, Predicted,
                                                                                    prevalence, 1)
    print("acc_test:", acc_test)
    dir_result = os.path.join(os.getcwd(), "result_all")
    if os.path.exists(os.path.join(dir_result, group + '_label_test_all.csv')):
        os.remove(os.path.join(dir_result, group + '_label_test_all.csv'))
    index_ = np.arange(1)
    d = {'acc': acc_test, 'fscore': fscore_test, 'sensitivity': sensitivity_test,'specificity': specificity_test,'precision': precision_test,
         'ppv': ppv_test,'npv': npv_test,'gmean': gmean_test}
    df = pd.DataFrame(data=d, index=[0])
    df.to_csv(os.path.join(dir_result, group + '_label_test_all.csv'),  header=0)

    """
    dir_slice_act = []
    for dir in np.arange(3):
        if dir == 0:
            for slicesindex in range(64, 192):
                dir_slice_act.append(str(dir) + '_' + str(slicesindex))
        if dir == 1:
            for slicesindex in range(80, 192):
                dir_slice_act.append(str(dir) + '_' + str(slicesindex))
        if dir == 2:
            for slicesindex in range(64, 192):
                dir_slice_act.append(str(dir) + '_' + str(slicesindex))
    print("dir_slice_act.shape:", len(dir_slice_act))
    print("dir_slice_act", dir_slice_act)
    """
    dir_slice_act = []
    dir_slice_act = np.arange(3)

    acc_list = []
    fscore_list = []
    sensitivity_list = []
    specificity_list = []
    precision_list = []
    ppv_list = []
    npv_list = []
    gmean_list = []
    #dir_slice = np.array(dir_slice)

    for i in np.arange(len(dir_slice_act)):
        find = dir_slice_act[i]
        print(dir_slice_act[i])
        index_pre_act = np.where(dir_slice == find)[0]
        # print("index_pre_act:", index_pre_act)
        # print("index_pre_act[0]:", index_pre_act[0])
        # print("index_pre_act[1]:", index_pre_act[1])

        pred_slice = Predicted[index_pre_act]
        Actual_slice = Actual[index_pre_act]

        # print("pred_slice:", pred_slice)
        # print("Actual_slice:", Actual_slice)
        prevalence = np.sum(Actual_slice) / len(Actual_slice)
        # print("prevalce:", prevalence)

        acc, fscore, sensitivity, specificity, precision, ppv, npv, gmean = top_k_error(Actual_slice, pred_slice,
                                                                                             prevalence, 1)

        acc_list.append(acc)
        fscore_list.append(fscore)
        sensitivity_list.append(sensitivity)
        specificity_list.append(specificity)
        precision_list.append(precision)
        ppv_list.append(ppv)
        npv_list.append(npv)
        gmean_list.append(gmean)

        print("find acc:", acc)


    if os.path.exists(os.path.join(dir_result, group + '_label_test_slice.csv')):
        os.remove(os.path.join(dir_result, group + '_label_test_slice.csv'))
    d = {'slice_index': dir_slice_act,'acc': acc_list, 'fscore': fscore_list, 'sensitivity': sensitivity_list,'specificity': specificity_list,'precision': precision_list,
         'ppv': ppv_list,'npv': npv_list,'gmean': gmean_list}
    df_label = pd.DataFrame(data=d, dtype=np.uint16)
    df_label.to_csv(os.path.join(dir_result, group + '_label_test_slice.csv'))



    print("acc_list:", acc_list)
    print("acc_list.shape", len(acc_list))

    acc_list = np.array(acc_list)
    # acc_list = float(acc_list)

    print("acc>0.9", acc_list[np.where(acc_list >= 0.9)[0]].shape[0])
    print("acc>0.8", acc_list[np.where(acc_list >= 0.8)[0]].shape[0] - acc_list[np.where(acc_list >= 0.9)[0]].shape[0])
    print("acc>0.7", acc_list[np.where(acc_list >= 0.7)[0]].shape[0] - acc_list[np.where(acc_list >= 0.8)[0]].shape[0])
    print("acc>0.6", acc_list[np.where(acc_list >= 0.6)[0]].shape[0] - acc_list[np.where(acc_list >= 0.7)[0]].shape[0])
    print("acc>0.5", acc_list[np.where(acc_list >= 0.5)[0]].shape[0] - acc_list[np.where(acc_list >= 0.6)[0]].shape[0])

    print("acc<0.5", acc_list[np.where(acc_list < 0.5)[0]].shape)

    sort_acc_list = acc_list
    sort_acc_list = np.sort(sort_acc_list)
    print("sort_acc_list:", sort_acc_list)
    dir_slice_act = np.array(dir_slice_act)
    print("dir_slice_act_0.8", dir_slice_act[np.where(acc_list >= 0.8)[0]])
    print("dir_slice_act_0.75", dir_slice_act[np.where(acc_list >= 0.75)[0]])
    print("dir_slice_act_0.5", dir_slice_act[np.where(acc_list < 0.5)[0]])

    #os.exit(0)
    subj_acc = get_acc_subject(index, Idx, slice, Actual, Predicted, test=1)

    return acc, subj_acc





def generate_train_batch(train_data, train_labels, batch_size, patient_ratio, random_batch_sampling_train=False):
    '''
    This function helps generate a batch of train data, and random crop, horizontally flip
    and whiten them at the same time
    :param train_data: 4D numpy array
    :param train_labels: 1D numpy array
    :param train_batch_size: int
    :return: augmented train batch data and labels. 4D numpy array and 1D numpy array
    '''
    patient_ratio = 0.5
    if random_batch_sampling_train is True:
        # Construct mini-batch by random sampling of subjects from whole dataset
        random_idx = random.sample(np.arange(0, train_labels.shape[0]), batch_size)
        batch_data = train_data[random_idx, ...]
        batch_label = train_labels[random_idx]
    else:
        control_index_all = [i for i, aa in enumerate(train_labels) if aa == 0]
        control_train_index = random.sample(control_index_all, int(math.floor((1.0 - patient_ratio) * batch_size)))
        patient_index_all = [i for i, aa in enumerate(train_labels) if aa == 1]
        #        print(len(patient_index_all))
        #        print(patient_ratio)
        #        print(batch_size)
        patient_train_index = random.sample(patient_index_all, int(math.ceil(patient_ratio * batch_size)))

        # training batch set
        data_train_index = np.concatenate((control_train_index, patient_train_index), axis=0)
        batch_data = train_data[data_train_index, ...]
        batch_label = train_labels[data_train_index]

        shuffle_ix = np.random.permutation(np.arange(len(batch_data)))
        batch_data = batch_data[shuffle_ix]
        batch_label = batch_label[shuffle_ix]

    return batch_data, batch_label




def get_data_csv(filename):

    #filename = "adni_gvcnn_train2_cn_ad_label.csv"
    #index, Idx, slice,Actual,Predicted
    index, Idx, slice1, Actual, Predicted = rflist._read_all_filelist_cn_ad_label(filename, ',')
    print("in get_data")
    print("index.shape", index.shape)
    print("Idx.shape", Idx.shape)

    print("slice.shape", slice1.shape)
    print("Actual.shape", Actual.shape)
    print("Predicted.shape", Predicted.shape)
    return index, Idx, slice1, Actual, Predicted


def get_result(filename, params, test=1):
    group = params['group']#"cn_ad"

    index, Idx, slice1, Actual, Predicted = get_data_csv(filename)

    print("in get_result")
    print("index.shape", index.shape)
    print("Idx.shape", Idx.shape)
    #print("direction.shape", direction.shape)
    print("slice.shape", slice1.shape)
    print("slice1:", slice1[0:200])
    print("Actual.shape", Actual.shape)
    print("Actual:", Actual[0:200])
    print("Predicted.shape", Predicted.shape)
    print("Predicted:", Predicted[0:200])



    #print("dir_slice:", dir_slice)
    Actual = np.array(Actual)
    prevalence = np.sum(Actual)/Actual.shape[0]
    acc_test, fscore_test, sensitivity_test, specificity_test, precision_test, ppv_test, npv_test, gmean_test = top_k_error(Actual, Predicted,
                                                                                    prevalence, 1)
    print("acc_test:", acc_test)
    #dir_result = filename.strip("test_mode_cv5_level_label.csv")
    dir_result = filename.strip(r"selection\test_mode_cv5_level_label.csv")
    if os.path.exists(os.path.join(dir_result, group + '_label_test_all.csv')):
        os.remove(os.path.join(dir_result, group + '_label_test_all.csv'))
    index_ = np.arange(1)
    d = {'acc': acc_test, 'fscore': fscore_test, 'sensitivity': sensitivity_test,'specificity': specificity_test,'precision': precision_test,
         'ppv': ppv_test,'npv': npv_test,'gmean': gmean_test}
    df = pd.DataFrame(data=d, index=[0])
    df.to_csv(os.path.join(dir_result, group + '_label_test_all.csv'),  header=0)

    print("os.path.join(dir_result, group + '_label_test_all.csv'):", os.path.join(dir_result, group + '_label_test_all.csv'))


    """
    dir_slice_act = []
    for dir in np.arange(3):
        if dir == 0:
            for slicesindex in range(64, 192):
                dir_slice_act.append(str(dir) + '_' + str(slicesindex))
        if dir == 1:
            for slicesindex in range(80, 192):
                dir_slice_act.append(str(dir) + '_' + str(slicesindex))
        if dir == 2:
            for slicesindex in range(64, 192):
                dir_slice_act.append(str(dir) + '_' + str(slicesindex))
    print("dir_slice_act.shape:", len(dir_slice_act))
    print("dir_slice_act", dir_slice_act)
    """
    dir_slice_act = []
    dir_slice_act = np.arange(64)
    acc_list = []
    fscore_list = []
    sensitivity_list = []
    specificity_list = []
    precision_list = []
    ppv_list = []
    npv_list = []
    gmean_list = []
    #dir_slice = np.array(dir_slice)

    for i in np.arange(len(dir_slice_act)):
        find = dir_slice_act[i] + 1
        print("find:", find + 1)
        #print(dir_slice_act[i])
        #print(np.where(slice1 == find))
        index_pre_act = np.where(slice1 == find)[0]
        #print("index_pre_act.shape:", index_pre_act.shape)
        # print("index_pre_act:", index_pre_act)
        # print("index_pre_act[0]:", index_pre_act[0])
        # print("index_pre_act[1]:", index_pre_act[1])

        pred_slice = Predicted[index_pre_act]
        Actual_slice = Actual[index_pre_act]

        # print("pred_slice:", pred_slice)
        # print("Actual_slice:", Actual_slice)
        prevalence = np.sum(Actual_slice) / len(Actual_slice)
        # print("prevalce:", prevalence)
        
        #print("pred_slice.shape:", pred_slice.shape)
        #print("Actual_slice.shape:", Actual_slice.shape)

        acc, fscore, sensitivity, specificity, precision, ppv, npv, gmean = top_k_error(Actual_slice, pred_slice,
                                                                                             prevalence, 1)



        acc_list.append(acc)
        fscore_list.append(fscore)
        sensitivity_list.append(sensitivity)
        specificity_list.append(specificity)
        precision_list.append(precision)
        ppv_list.append(ppv)
        npv_list.append(npv)
        gmean_list.append(gmean)

        print("find acc:", acc)


    if os.path.exists(os.path.join(dir_result, group + '_label_test_slice.csv')):
        os.remove(os.path.join(dir_result, group + '_label_test_slice.csv'))
        print("in os.path.exists(os.path.join(dir_result, group + '_label_test_slice.csv'))")
    print("acc_list before:", acc_list)
    d = {'slice_index': dir_slice_act + 1 ,'acc': acc_list, 'fscore': fscore_list, 'sensitivity': sensitivity_list,'specificity': specificity_list,'precision': precision_list,
         'ppv': ppv_list,'npv': npv_list,'gmean': gmean_list}
    df_label = pd.DataFrame(data=d)
    df_label.to_csv(os.path.join(dir_result, group + '_label_test_slice.csv'))


    print("dir_result:", dir_result)
    print("acc_list:", acc_list)
    print("acc_list.shape", len(acc_list))
    #sys.exit(0)
    acc_list = np.array(acc_list)
    # acc_list = float(acc_list)

    print("acc>0.9", acc_list[np.where(acc_list >= 0.9)[0]].shape[0])
    print("acc>0.8", acc_list[np.where(acc_list >= 0.8)[0]].shape[0] - acc_list[np.where(acc_list >= 0.9)[0]].shape[0])
    print("acc>0.7", acc_list[np.where(acc_list >= 0.7)[0]].shape[0] - acc_list[np.where(acc_list >= 0.8)[0]].shape[0])
    print("acc>0.6", acc_list[np.where(acc_list >= 0.6)[0]].shape[0] - acc_list[np.where(acc_list >= 0.7)[0]].shape[0])
    print("acc>0.5", acc_list[np.where(acc_list >= 0.5)[0]].shape[0] - acc_list[np.where(acc_list >= 0.6)[0]].shape[0])

    print("acc<0.5", acc_list[np.where(acc_list < 0.5)[0]].shape)

    sort_acc_list = acc_list
    sort_acc_list = np.sort(sort_acc_list)
    print("sort_acc_list:", sort_acc_list)
    dir_slice_act = np.array(dir_slice_act)
    print("dir_slice_act_0.8", dir_slice_act[np.where(acc_list >= 0.8)[0]])
    print("dir_slice_act_0.75", dir_slice_act[np.where(acc_list >= 0.75)[0]])
    print("dir_slice_act_0.5", dir_slice_act[np.where(acc_list < 0.5)[0]])

    #os.exit(0)
    subj_acc = get_acc_subject(index, Idx, slice1, Actual, Predicted, filename, params, test=1)

    return acc, subj_acc
#index, Idx, slice, Actual, Predicted, test=1
#def get_acc_subject():




def get_acc_subject(index, Idx, slice1, Actual, Predicted, filename, params, test=1):
    #C1ids = [3, 1, 2, 3, 2, 3]
    #dir_result = os.path.join(os.getcwd(), "result")
    dir_result = filename.strip(r"selection\test_mode_cv5_level_label.csv")
    group = params['group']
    """
    groupid = 0

    randomstate = 0
    foldIDS = 1
    groups = params['group']
    C0ids = [0, 0, 0, 2, 1, 1]
    group = groups[groupid]
    C0ID = C0ids[groupid]
    C1ID = C1ids[groupid]
    REG_thick_MAT = os.path.join(DATADIR, 'ADNI_filelist_Jan2021_0929.csv')

    Label, SubjID, SubjIDIndex, thick_select, Age, Gender, thick_base, Age_base, Gender_base, test_filepaths = \
        adni_get_subset_3D2D_slices(REG_thick_MAT, C0ID, C1ID, DATADIR, slicesindex=0, training=0, direction=0)

    print("test_filepaths.shape:", len(test_filepaths))
    print("Label.shape", Label.shape)

    print("index.shape", index.shape)
    print("Idx.shape", Idx.shape)
    #print("direction.shape", direction.shape)
    print("slice.shape", slice1.shape)
    print("Actual.shape", Actual.shape)
    print("Predicted.shape", Predicted.shape)
    """
    #print("index:", index)
    #print("slice1:", slice1)
    # print("Idx:", Idx)
    test_filepaths = np.unique(Idx)
    #print(test_filepaths)
    prection_label = []
    pre_auc = []
    Label = []
    print("Actual.shape:", Actual.shape)
    for i in np.arange(len(test_filepaths)):
        filename = test_filepaths[i]
        print(filename)
        select = np.where(Idx == filename)[0]
        subject_pre = Predicted[select]
        subject_sum = np.sum(subject_pre)
        subject_ave = subject_sum / 64.
        pre_auc.append(subject_ave)
        print("Actual[select]:", Actual[select])
        print("subject_pre:", subject_pre)
        print("Actual[select]:", Actual[select][0])
        Label.append(Actual[select][0])
        #os.exit()
        if subject_ave < 0.5:
            prection_label.append(0)
        else:
            prection_label.append(1)
        #print("sbuject_ave:", subject_ave, "subject_:", subject_sum / 64.)

        #print("subject_pre:", subject_pre)
        #print("np.sum(subject_pre):", np.sum(subject_pre))

        # print("select.shape:", select.shape)
        # print("select.shape[0]", select[0].shape)
        # print("select.shape", Idx[select[0]])

    prection_label = np.float16(np.array(prection_label))
    Label = np.float16(np.array(Label))

    print("Label:", Label)
    print("prection_label:", prection_label)
    prevalence = np.sum(Actual) / len(Actual)
    print("prevalence:", prevalence)
    acc, fscore, sensitivity, specificity, precision, ppv, npv, gmean = top_k_error(Label, prection_label,
                                                                                         prevalence, 1)
    print("acc:", acc)
    print("fscore:", fscore)
    print("sensitivity:", sensitivity)
    print("specificity:", specificity)
    print("precision:", precision)
    print("ppv:", ppv)
    print("npv:", npv)
    print("gmean:", gmean)
    #os.exit()
    #Actual[select]:
    if test != 0:
        roc_auc = plt_auc(Label, pre_auc, dir_result)

    if os.path.exists(os.path.join(dir_result, group + '_label_test_subject.csv')):
        os.remove(os.path.join(dir_result, group + '_label_test_subject.csv'))
    d = {'acc': acc, 'fscore': fscore, 'sensitivity': sensitivity,'specificity': specificity,'precision': precision,
         'ppv': ppv,'npv': npv,'gmean': gmean, 'auc': roc_auc}
    df = pd.DataFrame(data=d, index=[0])
    df.to_csv(os.path.join(dir_result, group + '_label_test_subject.csv'),  header=0)
    return acc



def plt_auc(label, prediction, dir_result):
    fpr, tpr, threshold = metrics.roc_curve(label, prediction)
    roc_auc = metrics.auc(fpr, tpr)
    plt.figure(figsize=(6, 6))
    plt.title('Validation ROC')
    plt.plot(fpr, tpr, 'b', label='Val AUC = %0.3f' % roc_auc)
    plt.legend(loc='lower right')
    plt.plot([0, 1], [0, 1], 'r--')
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    plt.ylabel('True Positive Rate')
    plt.xlabel('False Positive Rate')
    plt.savefig(os.path.join(dir_result, "roc_auc.jpg"))

    #plt.show()
    return roc_auc



#imagepath = r"G:/BaiduNetdiskDownload/ADNI_3DDATA/ADNI_3Ddata/"
#imagepath = '/data/ADNI_3Ddata'

#imagepath = r"G:/BaiduNetdiskDownload/ADNI_3DDATA/ADNI_3Ddata/"
imagepath = '/data/ADNI_3Ddata'
def preprocess(x, y):
    #x = tf.cast(x, dtype=tf.float32) /255.
    x = np.float32(x)
    x  = 2 * (x / 255.) - 1
    #x = 2 * (tf.cast(x, dtype=tf.float32) / 255.) - 1
    #y = tf.cast(y, dtype=tf.int32)
    y = np.int32(y)
    return x,y

def plot_roc(name, labels, predictions, **kwargs):
    fp, tp, _ = metrics.roc_curve(labels, predictions)
    auc = metrics.auc(fp, tp)
    plt.plot(100*fp, 100*tp, label=name, linewidth=2, **kwargs)
    plt.xlabel('False positives [%]')
    plt.ylabel('True positives [%]')
    plt.xlim([0,100.5])
    plt.ylim([0,100.5])
    plt.grid(True)
    ax = plt.gca()
    ax.set_aspect('equal')
    plt.savefig("test_roc.png")
    plt.legend(loc='lower right')
    print("auc:", auc)

def save_image(Label, thick_select):
    plt.xticks([])  # 关闭x坐标显示
    plt.yticks([])  # 关闭y坐标显示
    data = thick_select
    data = data.tolist()
    labels = Label
    labels = labels.tolist()
    for i in np.arange(len(Label)):
        fig = plt.imshow(data[i])
        name = './image/' + str(i) + '_' + str(int(labels[i]))+ '.jpg'
        plt.savefig(name)

"""
def generate_train_batch(train_data, train_labels, batch_size, random_batch_sampling_train=False):
    '''        patient_train_index = random.sample(patient_index_all, int(math.ceil(patient_ratio*batch_size)))

    This function helps generate a batch of train data, and random crop, horizontally flip
    and whiten them at the same time
    :param train_data: 4D numpy array
    :param train_labels: 1D numpy array
    :param train_batch_size: int
    :return: augmented train batch data and labels. 4D numpy array and 1D numpy array
    '''

    patient_ratio = 0.5

    if random_batch_sampling_train is True:
        # Construct mini-batch by random sampling of subjects from whole dataset
        random_idx = random.sample(np.arange(0, train_labels.shape[0]), batch_size)
        batch_data = train_data[random_idx, ...]
        batch_label = train_labels[random_idx]
    else:
        control_index_all = [i for i,aa in enumerate(train_labels) if aa == 0]
        control_train_index = random.sample(control_index_all, int(math.floor((1.0-patient_ratio)*batch_size)))
        patient_index_all = [i for i,aa in enumerate(train_labels) if aa == 1]
#        print(len(patient_index_all))
#        print(patient_ratio)
#        print(batch_size)
        patient_train_index = random.sample(patient_index_all, int(math.ceil(patient_ratio*batch_size)))

        # training batch set
        data_train_index = np.concatenate((control_train_index, patient_train_index), axis=0)
        batch_data = train_data[data_train_index, ...]
        batch_label = train_labels[data_train_index]

    return batch_data, batch_label
"""
#def cal_loss(logits):
    



def evalute(epoch, data_train, target_train, model, batch_size, roc=0):
    # 计算train acc 和 loss
    total_num = 0
    total_correct = 0
    total_loss = 0
    # loss = 0
    size = data_train.shape[0]
    predictions = np.empty(size)

    for begin in range(0, size, batch_size):
        end = begin + batch_size
        end = min([end, size])

        batch_data = np.zeros((batch_size, data_train.shape[1], data_train.shape[2], data_train.shape[3]))
        batch_label = np.zeros((batch_size))
        tmp_data = data_train[begin:end, ...]
        # tmp_label = target_train[begin:end, ...]
        tmp_label = target_train[begin:end]
        # print("tmp_data.shape", tmp_data.shape)
        # print("tmp_label.shape", tmp_label.shape)
        if type(tmp_data) is not np.ndarray:
            tmp_data = tmp_data.toarray()  # convert sparse matrices
        batch_data[:end - begin] = tmp_data
        batch_data = batch_data.astype(np.float32)
        batch_label[:end - begin] = tmp_label
        batch_label = batch_label.astype(np.int32)
        # print("batch_label.shape", batch_label.shape)
        # feed_dict = {self.ph_data: batch_data, self.ph_dropout: 1}
        batch_data, batch_label = preprocess(batch_data, batch_label)

        # Compute loss if labels are given.
        logits = model(batch_data)
        
        
        
        prob = tf.nn.softmax(logits, axis=1)
        pred = tf.argmax(prob, axis=1)
        batch_pred = tf.cast(pred, dtype=tf.int32)
        predictions[begin:end] = batch_pred[:end - begin]
        # logitss[begin:end, :] = batch_logits[:end - begin, :]
        # fc_datas[begin:end, ...] = batch_fcdata[:end - begin, ...]
        # print(batch_data.shape, batch_label.shape, batch_pred.shape)
        correct = tf.cast(tf.equal(batch_pred, batch_label), dtype=tf.int32)
        correct = tf.reduce_sum(correct)

        total_num += batch_data.shape[0]
        total_correct += int(correct)
        y_onehot = tf.one_hot(batch_label, depth=2)
        loss = tf.losses.categorical_crossentropy(y_onehot, logits, from_logits=True)
        loss = tf.reduce_mean(loss)
        total_loss += loss
    total_loss = float(total_loss/(data_train.shape[0]/(batch_size+1)))
    tl_acc = total_correct / total_num
    
    prevalence = float(np.sum(target_train))/float(len(target_train))
    #print("target_train.shape:", target_train.shape, "predictions.shape:", len(predictions), "prevalence:", prevalence)
    #(target_train)
    acc, fscore, sensitivity, specificity, precision, ppv, npv, gmean = top_k_error(target_train, predictions, prevalence, 1)
    #acc, fscore, sensitivity, specificity, precision, ppv, npv, gmean
    if roc == 1:
        plot_roc("Test Baseline", target_train, predictions, color='blue', linestyle='--')
        plt.legend(loc='lower right')

    print(epoch, 'train acc:', tl_acc, 'acc:', acc, 'loss:', float(total_loss))
    del batch_data, batch_label, prob, pred, correct, total_num, total_correct, prevalence
    gc.collect()
    return acc, fscore, sensitivity, specificity, precision, ppv, npv, gmean, total_loss






def top_k_error(y, y_pred, prevalence, k):

    """
    Evaluates different metrics based on the list of true labels and predicted labels.

    Args:
        y: (list) true labels
        y_pred: (list) corresponding predictions

    Returns:
        (dict) ensemble of metrics
    """

    true_positive = np.sum((y_pred == 1) & (y == 1))
    true_negative = np.sum((y_pred == 0) & (y == 0))
    false_positive = np.sum((y_pred == 1) & (y == 0))
    false_negative = np.sum((y_pred == 0) & (y == 1))

    accuracy = (true_positive + true_negative) / (true_positive + true_negative + false_positive + false_negative)

    if (true_positive + false_negative) != 0:
        sensitivity = true_positive / (true_positive + false_negative)
    else:
        sensitivity = 0.0

    if (false_positive + true_negative) != 0:
        specificity = true_negative / (false_positive + true_negative)
    else:
        specificity = 0.0

    if (true_positive + false_positive) != 0:
        ppv = true_positive / (true_positive + false_positive)
    else:
        ppv = 0.0

    if (true_negative + false_negative) != 0:
        npv = true_negative / (true_negative + false_negative)
    else:
        npv = 0.0

    balanced_accuracy = (sensitivity + specificity) / 2

    gmean = np.sqrt(np.multiply(sensitivity, specificity))

    results = {'accuracy': accuracy,
               'balanced_accuracy': balanced_accuracy,
               'sensitivity': sensitivity,
               'specificity': specificity,
               'ppv': ppv,
               'npv': npv,
               'gmean': gmean
               }
    
    # precision
    deno_pre = np.add(true_positive, false_negative)
    if deno_pre == 0:
        precision = 0.
    else:
        precision = np.divide(true_positive, 1.*deno_pre)

    # fscore
    nume = np.multiply(sensitivity, precision)
    if nume == 0.:
        fscore = 0.
    else:
        fscore = 2. * np.divide( np.multiply(sensitivity, precision), 1.*np.add(sensitivity, precision) )
    
    
    return balanced_accuracy, fscore, sensitivity, specificity, precision, ppv, npv, gmean
    #return results



def top_k_error1(labels, predictions, prevalence, k):
    '''
    Calculate the top-k error
    :param predictions: 2D tensor with shape [batch_size, num_labels]
    :param labels: 1D tensor with shape [batch_size, 1]
    :param k: int
    :return: tensor with shape [1]
    '''
    cm = metrics.confusion_matrix(labels, predictions)

    # error 
    nume_err = np.add(cm[1][0], cm[0][1])
    den_err1 = np.add(cm[0][0], cm[1][1])
    den_err2 = np.add(cm[1][0], cm[0][1])
    deno_err = np.add(den_err1, den_err2)
    if nume_err == 0:
        error = 0.
    else:
        error = np.divide(nume_err, 1.*deno_err)
    acc = 1. - error
    
    # sensitivity
    deno_sen = np.add(cm[1][0], cm[1][1])
    if deno_sen == 0:
        sensitivity = 0.
    else:
        sensitivity = np.divide(cm[1][1], 1.*deno_sen) 
        
    # specificity
    deno_spe = np.add(cm[0][0], cm[0][1])
    if deno_spe == 0:
        specificity = 0.
    else:
        specificity = np.divide(cm[0][0], 1.*deno_spe)
    
    # precision
    deno_pre = np.add(cm[1][1], cm[0][1])
    if deno_pre == 0:
        precision = 0.
    else:
        precision = np.divide(cm[1][1], 1.*deno_pre)

    # fscore
    nume = np.multiply(sensitivity, precision)
    if nume == 0.:
        fscore = 0.
    else:
        fscore = 2. * np.divide( np.multiply(sensitivity, precision), 1.*np.add(sensitivity, precision) )

    # ppv
    nume_ppv = np.multiply(sensitivity, prevalence)
    deno_ppv = np.multiply(1.0-specificity, 1.0-prevalence)
    if np.add(nume_ppv, deno_ppv) == 0:
        ppv = 0.
    else:
        ppv = np.divide(nume_ppv, np.add(nume_ppv, 1.*deno_ppv)) 

    # npv
    nume_npv = np.multiply(specificity, 1.0-prevalence)
    deno_npv = np.multiply(1.0-sensitivity, prevalence)
    if np.add(nume_npv, deno_npv) == 0:
        npv = 0.
    else:
        npv = np.divide(nume_npv, np.add(nume_npv, 1.*deno_npv)) 
    
    # G-mean (geometric mean) = squared root of (sensitivity x specificity)
    gmean = np.sqrt(np.multiply(sensitivity, specificity))

    balanced_accuracy = (sensitivity + specificity) / 2
    
    return balanced_accuracy, fscore, sensitivity, specificity, precision, ppv, npv, gmean



def print_mean_std(target_train_label, Age, readnum):
    """
    get the average and std of distribution from dataSet

    """
    print("np.where(target_train_label == 1)[0].shape:", len(np.where(target_train_label == 1)[0]))
    print("%s AD age average: %f"%(readnum ,np.mean(Age[np.where(target_train_label == 1)[0]])))
    print("%s AD age std: %f"%(readnum, np.std(Age[np.where(target_train_label == 1)[0]])))

    print("np.where(target_train_label == 0)[0].shape:", len(np.where(target_train_label == 0)[0]))
    print("%s  NC age average: %f"%(readnum , np.mean(Age[np.where(target_train_label == 0)[0]])))
    print("%s  NC age std: %f"%(readnum ,np.std(Age[np.where(target_train_label == 0)[0]])))





def get_filepath_between_age(filepath,age_train, Age1, Age2):
    if Age1 == 0:
        age_train_NC_locat65 = (np.where((age_train > Age1) & (age_train <= Age2)))[0]
        age_train_NC_locat95 = (np.where(age_train > 85))[0]
        age_train_NC_locat = np.r_[age_train_NC_locat65, age_train_NC_locat95]  #((age_train_NC_locat65, age_train_NC_locat95))
        #print("age_train_NC70:", age_train_NC_locat)
        filepaths_train_NC = filepath[age_train_NC_locat]
        age_train_NC_last = age_train[age_train_NC_locat]
        #print("filepaths_train_NC70:", filepaths_train_NC70)
        #print("age_train_NC[filepaths_train_NC70]:", filepath[age_train_NC_locat])
    else:
        age_train_NC_locat = (np.where((age_train > Age1) & (age_train <= Age2)))[0]
        #print("age_train_NC70:", age_train_NC_locat)
        filepaths_train_NC= filepath[age_train_NC_locat]
        age_train_NC_last = age_train[age_train_NC_locat]
        #print("filepaths_train_NC70:", filepaths_train_NC70)
        #print("age_train_NC[filepaths_train_NC70]:", filepath[age_train_NC_locat])
    return filepaths_train_NC, age_train_NC_last

def random_shuffle(data,label):
    randnum = 0
    np.random.seed(randnum)
    np.random.shuffle(data)
    np.random.seed(randnum)
    np.random.shuffle(label)
    return data, label

def adni_generate_unique_SubjId(SubjID):
    num = 0
    name=[]
    SubjIDIndex = np.array(range(len(SubjID)))
    SubjID_unique = []
    for k in range(len(SubjID)):
        if SubjID[k] != name:
            num = num+1
            name = SubjID[k]
            SubjIDIndex[k] = num-1
            SubjID_unique.append(name)
        else:
            SubjIDIndex[k] = num-1
    return SubjIDIndex
def adni_generate_unique_SubjIdIndex(SubjID):
    num = 0
    name=-1
    SubjIDIndex = np.array(range(SubjID.shape[0]))
    SubjID_unique = []
    for k in range(len(SubjID)):
        if SubjID[k] != name:
            num = num+1
            name = SubjID[k]
            SubjIDIndex[k] = num-1
            SubjID_unique.append(name)
        else:
            SubjIDIndex[k] = num-1
    return SubjIDIndex            

def adni_get_subset(filename, label1, label2, readdata):
    f = h5py.File(filename, 'r')
    print(list(f.keys()))
    Label = np.transpose(np.array(f.get('Label')).astype(int))[0]
    Age   = np.array(f.get('Age'))
    Gender= np.array(f.get('Gender'))

    if readdata > 0:
        lthick = np.array(f.get('lthick_regular'))
        rthick = np.array(f.get('rthick_regular'))
        thickdata = np.concatenate([lthick, rthick], axis=1)
        del lthick, rthick
    else:
        thickdata = []
        
    SubjID=[]
    for column in f['SubjID']:
        row_data = ''.join(map(chr, f[column[0]][:]))
        SubjID.append(row_data)
    
    select_index = [i for i,aa in enumerate(Label) if aa == label1 or aa == label2]
    base_index   = [i for i,aa in enumerate(Label) if aa < label1]

    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)
    Label_s = Label[select_index]
    Age_s   = Age[select_index]
    Gender_s= Gender[select_index]
    if readdata > 0:
        thick_s = thickdata[select_index]
    if len(base_index)>0:
        if readdata >0:
            thick_base = thickdata[base_index]
        else:
            thick_base = []
        Age_base = Age[base_index]
        Gender_base = Gender[base_index]
    else:
        thick_base  = []
        Age_base    = []
        Gender_base = []
    Label_s[Label_s==label1] = 0
    Label_s[Label_s==label2] = 1
    return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index, \
        thick_s, Age_s, Gender_s, thick_base, Age_base, Gender_base
def adni_get_subset_3D2D_bak(listname, label1, label2, imagepath, direction, readnum=-1, training=1):
    filepaths, Label, Age, Gender, study, SubjID, waveid, subjtype = rflist._read_all_filelist(listname, ',')
    thickdata=[]
    if readnum<= 0:
        readnum = len(Label)
    if readnum < len(Label):
        filepaths = filepaths[0:readnum]
        Label = Label[0:readnum]
        Age = Age[0:readnum]
        Gender = Gender[0:readnum]
        study = study[0:readnum]
        SubjID = SubjID[0:readnum]
        waveid = waveid[0:readnum]
    for k in range(readnum):
        filename = os.path.join(imagepath, filepaths[k]+'.nii.gz')
        img = nib.load(filename)
#        print(img.shape)
        data = img.get_data()
        xData=np.mean(data,axis = direction)
        thickdata.append(xData)
    thickdata = np.array(thickdata)
    thickdata = np.expand_dims(thickdata, axis=3)
    if training == 1:
        select_index = [i for i,aa in enumerate(Label) if aa == label1 or aa == label2]
    elif training == 0:
        select_index = [i for i,aa in enumerate(Label) if aa == label1 or aa == label2]
    else:
        select_index = [i for i,aa in enumerate(Label) if aa >= 0]
    base_index   = [i for i,aa in enumerate(Label) if aa < label1]

    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)
    Label_s = Label[select_index]
    Age_s   = Age[select_index]
    Gender_s= Gender[select_index]
    thick_s = thickdata[select_index]
    if len(base_index)>0:
        thick_base = thickdata[base_index]
        Age_base = Age[base_index]
        Gender_base = Gender[base_index]
    else:
        thick_base  = []
        Age_base    = []
        Gender_base = []
    Label_s[Label_s==label1] = 0
    Label_s[Label_s==label2] = 1
    return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index, \
        thick_s, Age_s, Gender_s, thick_base, Age_base, Gender_base
def _projection_3D2(image1, angle1, angle2):
    if angle1 == 0 & angle2 == 0:
        return np.mean(image1,axis = 0)
    if angle1 == 0 & angle2 == 90:
        return np.mean(image1,axis = 1)
    if angle1 == 90 & angle2 == 90:
        return np.mean(image1,axis = 2)   
    # rotate along 0-axis, rotate axis 2 to 1    
    image2 = ndimage.interpolation.rotate(image1, angle1, mode='nearest', axes=(1, 2), reshape=False)
# rotate along 2-axis, rotation axis 1 to 0
    image = ndimage.interpolation.rotate(image2, angle2, mode='nearest', axes=(0, 1), reshape=False)
#    return np.mean(image, axis = 0)
    return np.mean(image,axis = 0)
def adni_get_subset_3D2D(listname, label1, label2, imagepath, direction, readnum=-1, training=1):
    filepaths, Label, Age, Gender, study, SubjID, waveid, subjtype = rflist._read_all_filelist(listname, ',')
 
    if readnum<= 0:
        readnum = len(Label)
    if readnum < len(Label):
        filepaths = filepaths[0:readnum]
        Label = Label[0:readnum]
        Age = Age[0:readnum]
        Gender = Gender[0:readnum]
        study = study[0:readnum]
        SubjID = SubjID[0:readnum]
        waveid = waveid[0:readnum]
        subjtype = subjtype[0:readnum]
#    thickdata=[]
#    for k in range(readnum):
#        filename = os.path.join(imagepath, filepaths[k]+'.nii.gz')
#        img = nib.load(filename)
##        print(img.shape)
#        data = img.get_data()
#        xData=np.mean(data,axis = direction)
#        thickdata.append(xData)
#    thickdata = np.array(thickdata)
#    thickdata = np.expand_dims(thickdata, axis=3)
    select_index=[]
    for i in range(len(Label)):
        if training == 1:
            if subjtype[i] == 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        elif training == 0:
            if subjtype[i] > 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        else:
            select_index.append(i)
    base_index   = [i for i,aa in enumerate(Label) if aa < label1]

    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)
    
    Label_s = Label[select_index]
    Age_s   = Age[select_index]
    Gender_s= Gender[select_index]
    
    thick_s = []
    for k in range(len(select_index)):
        filename = os.path.join(imagepath, filepaths[select_index[k]]+'.nii.gz')
        img = nib.load(filename)
##        print(img.shape)
        data = img.get_data()
        xData=_projection_3D2(data, direction[0], direction[1])
        thick_s.append(xData)
    thick_s = np.array(thick_s)
    thick_s = np.expand_dims(thick_s, axis=3)
#    thick_s = thickdata[select_index]
    if len(base_index)>0:
        thick_base = []#thickdata[base_index]
        Age_base = Age[base_index]
        Gender_base = Gender[base_index]
    else:
        thick_base  = []
        Age_base    = []
        Gender_base = []
    Label_s[Label_s==label1] = 0
    Label_s[Label_s==label2] = 1
    return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index, \
        thick_s, Age_s, Gender_s, thick_base, Age_base, Gender_base

#def get_train_valid_slices_newbatch(filepaths, labels, imagepath, random=0):
def get_train_valid_slices_newbatch(filepaths):
    edge = 32
    train_nc_data = dict()
    train_ad_data = dict()
    """
    print("len(filepaths):", len(filepaths))
    print("len(filepaths)/4:", len(filepaths)/4)
    print("len(filepaths)/4:", int(len(filepaths)) / 4)
    """
    for i in range(int(len(filepaths))//4):
        thick_nc = []
        thick_ad = []
        a = 65+5*i
        filename_ad = "filepaths_train_AD"+str(int(a))
        filename_nc = "filepaths_train_NC"+str(int(a))
        #print("len(filepaths[filename_nc]:)", filepaths[filename_nc])
        #print("filename_ad:", filename_ad)
        #print("filename_nc:", filename_nc)



        #if random > 0:
            #filepaths, labels = random_shuffle(filepaths, labels)
        random.shuffle(filepaths[filename_nc])
        """
        for k in range(len(filepaths[filename_nc])):
            filename = os.path.join(imagepath, filepaths[filename_nc][k] + '.nii.gz')
            img = nib.load(filename)
            ##        print(img.shape)
            data = img.get_data()
            for slicesindex in range(64, 192):
                xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
                xData = np.transpose(xData, (1, 2, 0))
                thick_nc.append(xData)
            for slicesindex in range(80, 192):
                xData = data[edge:-edge, slicesindex - 1:slicesindex + 2, edge:-edge];
                xData = np.transpose(xData, (0, 2, 1))
                thick_nc.append(xData)
            for slicesindex in range(64, 192):
                xData = data[edge:-edge, edge:-edge, slicesindex - 1:slicesindex + 2];
                thick_nc.append(xData)
        """

        #for test
        for k in range(len(filepaths[filename_nc])):
            filename = os.path.join(imagepath, filepaths[filename_nc][k] + '.nii.gz')
            img = nib.load(filename)
            ##        print(img.shape)
            data = img.get_data()
            for slicesindex in range(80, 81):
                xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
                xData = np.transpose(xData, (1, 2, 0))
                thick_nc.append(xData)


        print("NC %d is done!"%k)
        thick_nc = np.array(thick_nc)

        print("thick_s.shape:", thick_nc.shape)
        #print("labels.shape:", len(label_s))
        random.shuffle(thick_nc)
        train_nc_data[filename_nc] = thick_nc


        random.shuffle(filepaths[filename_ad])
        """
        for k in range(len(filepaths[filename_ad])):
            filename = os.path.join(imagepath, filepaths[filename_ad][k] + '.nii.gz')
            img = nib.load(filename)
            ##        print(img.shape)
            data = img.get_data()
            for slicesindex in range(64, 192):
                xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
                xData = np.transpose(xData, (1, 2, 0))
                thick_ad.append(xData)
            for slicesindex in range(80, 192):
                xData = data[edge:-edge, slicesindex - 1:slicesindex + 2, edge:-edge];
                xData = np.transpose(xData, (0, 2, 1))
                thick_ad.append(xData)
            for slicesindex in range(64, 192):
                xData = data[edge:-edge, edge:-edge, slicesindex - 1:slicesindex + 2];
                thick_ad.append(xData)
        """
        #for test

        for k in range(len(filepaths[filename_ad])):
            filename = os.path.join(imagepath, filepaths[filename_ad][k] + '.nii.gz')
            img = nib.load(filename)
            ##        print(img.shape)
            data = img.get_data()
            for slicesindex in range(80, 81):
                xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
                xData = np.transpose(xData, (1, 2, 0))
                thick_ad.append(xData)

        print("AD %d is done!"%k)
        thick_ad = np.array(thick_ad)

        print("AD thick_s.shape:", thick_ad.shape)
        #print("labels.shape:", len(label_s))
        random.shuffle(thick_ad)
        train_ad_data[filename_ad] = thick_ad
        #print("train_ad_data（key）:", train_ad_data["filepaths_train_AD65"])
        #if random>0:
            #thick_s, label_s = random_shuffle(thick_s, label_s)
        #del thick_s, label_s
    #print("labels:", labels_s)

    #import sys
    #sys.exit(0)
    print("train_nc_data.key:", train_nc_data.keys())
    print("train_ad_data.key:", train_ad_data.keys())

    return train_nc_data, train_ad_data




def get_train_valid_slices(filepaths, labels, imagepath, random=0):
    thick_s = []
    edge = 32
    label_s = []

    if random>0:
        filepaths,labels = random_shuffle(filepaths, labels)
        print("random = 0")
    
    for k in range(len(filepaths)):
        filename = os.path.join(imagepath, filepaths[k] + '.nii.gz')
        img = nib.load(filename)
        ##        print(img.shape)
        data = img.get_data()
        
        for slicesindex in range(64, 192):
            xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
            xData = np.transpose(xData, (1, 2, 0))
            thick_s.append(xData)
            label_s.append(labels[k])
        for slicesindex in range(80, 192):
            xData = data[edge:-edge, slicesindex - 1:slicesindex + 2, edge:-edge];
            xData = np.transpose(xData, (0, 2, 1))
            thick_s.append(xData)
            label_s.append(labels[k])
        for slicesindex in range(64, 192):
            xData = data[edge:-edge, edge:-edge, slicesindex - 1:slicesindex + 2];
            thick_s.append(xData)
            label_s.append(labels[k])
    """

            #for test
    
    for k in range(len(filepaths)):
        filename = os.path.join(imagepath, filepaths[k] + '.nii.gz')
        img = nib.load(filename)
        ##        print(img.shape)
        data = img.get_data()
        for slicesindex in range(100, 101):
            xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
            xData = np.transpose(xData, (1, 2, 0))
            thick_s.append(xData)
            label_s.append(labels[k])
        print("%d is done!"%k)
    """
    thick_s = np.array(thick_s)
    
    print("thick_s.shape:", thick_s.shape)
    print("labels.shape:", len(label_s))
    if random>0:
        thick_s, label_s = random_shuffle(thick_s, label_s)
        print("random = 0_1")
        #del thick_s, label_s
    #print("labels:", labels_s)

    return thick_s, label_s


def random_shuffle_test(filepaths, labels, test_set):
    randnum = 0
    np.random.seed(randnum)
    np.random.shuffle(filepaths)
    np.random.seed(randnum)
    np.random.shuffle(labels)
    np.random.seed(randnum)
    np.random.shuffle(test_set)
    
    return filepaths, labels, test_set

def get_test_slices(filepaths, labels, imagepath, test_set, random=0):
    thick_s = []
    edge = 32
    label_s = []
    TestSet = []

    direction_s =[]
    slice_s = []


    if random>0:
        filepaths, labels, test_set = random_shuffle_test(filepaths, labels, test_set)

    print("len(filepaths):", len(filepaths))
    print("filepaths[k]", filepaths[len(filepaths) - 1])
    for k in range(len(filepaths)):
        filename = os.path.join(imagepath, filepaths[k] + '.nii.gz')
        
        img = nib.load(filename)
        ##        print(img.shape)
        data = img.get_data()
        for slicesindex in range(64, 192):
            xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
            xData = np.transpose(xData, (1, 2, 0))
            thick_s.append(xData)
            label_s.append(labels[k])
            TestSet.append(test_set[k])
            direction_s.append(0)
            slice_s.append(slicesindex)
        for slicesindex in range(80, 192):
            xData = data[edge:-edge, slicesindex - 1:slicesindex + 2, edge:-edge];
            xData = np.transpose(xData, (0, 2, 1))
            thick_s.append(xData)
            label_s.append(labels[k])
            TestSet.append(test_set[k])
            direction_s.append(1)
            slice_s.append(slicesindex)
        for slicesindex in range(64, 192):
            xData = data[edge:-edge, edge:-edge, slicesindex - 1:slicesindex + 2];
            thick_s.append(xData)
            label_s.append(labels[k])
            TestSet.append(test_set[k])
            direction_s.append(2)
            slice_s.append(slicesindex)
        print("%d is done!"%k)
    thick_s = np.array(thick_s)

    print("thick_s.shape:", thick_s.shape)
    print("labels.shape:", len(label_s))
    print("TestSet.shape:", len(TestSet))
    if random>0:
        thick_s, label_s, TestSet = random_shuffle_test(thick_s, label_s, TestSet)
    return thick_s, label_s, TestSet, direction_s, slice_s


def getAge(train_age, subtype):
    if subtype == 0:
        print("NC:")
    else:
        print("AD:")
    #print("train_age:", train_age)
    print("train_age.shape:", len(train_age))
    print("train_age.max:", np.max(train_age))
    print("train_age.min:", np.min(train_age))
    #print("train_age.shape:", np.where((train_age>0)&(train_age <= 65))[0])
    print("train_age.shape65:", len(np.where((train_age > 0) & (train_age <= 65))[0]))
    print("train_age.shape70:", len(np.where((train_age > 65) & (train_age <= 70))[0]))
    print("train_age.shape75:", len(np.where((train_age > 70) & (train_age <= 75))[0]))
    print("train_age.shape80:", len(np.where((train_age > 75) & (train_age <= 80))[0]))
    print("train_age.shape85:", len(np.where((train_age > 80) & (train_age <= 85))[0]))
    print("train_age.shape90:", len(np.where((train_age > 85) & (train_age <= 90))[0]))
    print("train_age.shape65:", len(np.where((train_age > 90) & (train_age <= 100))[0]))
    if subtype == 0:
        print("NC:")
    else:
        print("AD:")




def adni_get_subset_3D2D_slices(listname, label1, label2, imagepath, slicesindex=64, readnum=-1, training=1, direction=0):
    filepaths, Label, Age, Gender, study, SubjID, waveid, subjtype = rflist._read_all_filelist(listname, ',')

    if readnum <= 0:
        readnum = len(Label)

    if readnum < len(Label):
        filepaths = filepaths[0:readnum]
        Label = Label[0:readnum]
        Age = Age[0:readnum]
        Gender = Gender[0:readnum]
        study = study[0:readnum]
        SubjID = SubjID[0:readnum]
        waveid = waveid[0:readnum]
        subjtype = subjtype[0:readnum]
    print("in Label.shape:", Label.shape)
    select_index = []
    for i in range(len(Label)):
        if training == 1:
            if subjtype[i] < 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        elif training == 0:
            #print("training == 0")
            if subjtype[i] == 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        else:
            select_index.append(i)
    base_index = [i for i, aa in enumerate(Label) if aa < label1]

    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)

    filepaths = np.array(filepaths)
    Label_s = Label[select_index]
    Age_s = Age[select_index]
    Gender_s = Gender[select_index]
    filepaths_s = filepaths[select_index]

    thick_s = []
    edge = 32
    """
    for k in range(1):
        filename = os.path.join(imagepath, filepaths[select_index[k]] + '.nii.gz')
        print("filename:", filename)
        import sys
        sys.exit(0)
        img = nib.load(filename)
        ##        print(img.shape)
        data = img.get_data()
        #        xData=_projection_3D2(data, direction[0], direction[1])
        if direction == 0:
            xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
            xData = np.transpose(xData, (1, 2, 0))
        elif direction == 1:
            xData = data[edge:-edge, slicesindex - 1:slicesindex + 2, edge:-edge];
            xData = np.transpose(xData, (0, 2, 1))
        elif direction == 2:
            xData = data[edge:-edge, edge:-edge, slicesindex - 1:slicesindex + 2];

        thick_s.append(xData)
    """
    thick_s = np.array(thick_s)
    #    thick_s = np.expand_dims(thick_s, axis=3)

    if len(base_index) > 0:
        thick_base = []  # thickdata[base_index]
        Age_base = Age[base_index]
        Gender_base = Gender[base_index]
    else:
        thick_base = []
        Age_base = []
        Gender_base = []
    Label_s[Label_s == label1] = 0
    Label_s[Label_s == label2] = 1
    print("Label_s.shape:", len(Label_s))

    return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index,  thick_s, Age_s, Gender_s, thick_base, Age_base, Gender_base, filepaths_s


def adni_get_subset_3D2D_slices_for_eval(listname, label1, label2, imagepath, slicesindex, readnum=-1, training=1, direction=0):
    filepaths, Label, Age, Gender, study, SubjID, Viscode, subjtype = rflist._read_all_filelist(listname, ',')
   
    if readnum<= 0:
        readnum = len(Label)
    nlen = len(Label) 
    if readnum < len(Label):
        filepaths = filepaths[0:readnum]
        Label = Label[0:readnum]
        Age = Age[0:readnum]
        Gender = Gender[0:readnum]
        study = study[0:readnum]
        SubjID = SubjID[0:readnum]
        Viscode = Viscode[0:readnum]
        subjtype = subjtype[0:readnum]

    select_index=[]
    for i in range(len(Label)):
        if training == 1:
            if subjtype[i] == 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        elif training == 0:
            if subjtype[i] > 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        else:
            select_index.append(i)
  
    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)
    
    Label_s = Label[select_index]
    Age_s   = Age[select_index]
    Gender_s= Gender[select_index]
    study_s = study[0:readnum]
    SubjID_s = SubjID[0:readnum]
    Viscode_s = Viscode[0:readnum]
    subjtype_s = subjtype[0:readnum]
    thick_s = []
    edge=32
    for k in range(len(select_index)):
        filename = os.path.join(imagepath, filepaths[select_index[k]]+'.nii.gz')
        img = nib.load(filename)
##        print(img.shape)
        data = img.get_data()
#        xData=_projection_3D2(data, direction[0], direction[1])

        if direction==0:
            xData = data[slicesindex-1:slicesindex+2, edge:-edge, edge:-edge];
            xData = np.transpose(xData, (1,2,0))
        elif direction==1:
            xData = data[edge:-edge, slicesindex-1:slicesindex+2, edge:-edge];
            xData = np.transpose(xData, (0,2,1))
        elif direction==2:
            xData = data[edge:-edge, edge:-edge, slicesindex-1:slicesindex+2];        
        thick_s.append(xData)
        
    thick_s = np.array(thick_s)
#    thick_s = np.expand_dims(thick_s, axis=3)
    if training == 1:
        Label_s[Label_s==label1] = 0
        Label_s[Label_s==label2] = 1
    return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index, \
        thick_s, Age_s, Gender_s, SubjID_s, study_s, Viscode_s, subjtype_s, nlen, readnum        
def adni_get_subset_3D2D_multi_slices(listname, label1, label2, imagepath, slicescutnum=64, edge=64, direction = 0, readstart=0, readnum=-1, training=1):
    filepaths, Label, Age, Gender, study, SubjID, Viscode, subjtype = rflist._read_all_filelist(listname, ',')
    if readstart<0:
        readstart=0
    nlen = len(Label)
    if readnum< 0:
        readnum = nlen-readstart
    if readstart+readnum>nlen:
        readnum = nlen-readstart
    if readnum > 0:
        filepaths = filepaths[readstart:readstart+readnum]
        Label = Label[readstart:readstart+readnum]
        Age = Age[readstart:readstart+readnum]
        Gender = Gender[readstart:readstart+readnum]
        study = study[readstart:readstart+readnum]
        SubjID = SubjID[readstart:readstart+readnum]
        Viscode = Viscode[readstart:readstart+readnum]
        subjtype = subjtype[readstart:readstart+readnum]
    else:
        Label_s = []
        Age_s   = []
        Gender_s= []
        thick_s = []
        SubjIDIndex_sub_in_whole = []
        SubjIDIndex_sub_index = []
        SubjID_s =[]
        Viscode_s =[]
        SliceID_s =[]
        return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index, \
            thick_s, Age_s, Gender_s, SubjID_s, Viscode_s, SliceID_s, nlen, readnum 
    select_index=[]
    for i in range(len(Label)):
        if training == 1:
            if subjtype[i] == 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        elif training == 0:
            if subjtype[i] > 0 and (Label[i] == label1 or Label[i] == label2):
                select_index.append(i)
        else:
            select_index.append(i)

    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
    SubjIDIndex_sub_in_whole_base = SubjIDIndex_in_whole[select_index]
    SubjIDIndex_sub_index_base = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole_base)
    
    Label_s = []
    Age_s   = []
    Gender_s= []
    thick_s = []
    SubjIDIndex_sub_in_whole = []
    SubjIDIndex_sub_index = []
    SubjID_s =[]
    Viscode_s =[]
    SliceID_s =[]
    Label_base  = Label[select_index]
    Age_base    = Age[select_index]
    Gender_base = Gender[select_index]
        
    slicescut_start = int((slicescutnum+1)/2);
    slicescut_end = 256-(slicescutnum-slicescut_start);
    for k in range(len(select_index)):
        filename = os.path.join(imagepath, filepaths[select_index[k]]+'.nii.gz')
        img = nib.load(filename)
##        print(img.shape)
        data = img.get_data()
#        xData=_projection_3D2(data, direction[0], direction[1])
        for slicesindex in range(slicescut_start, slicescut_end):
            if direction==2:
                if edge>0:
                    xData = data[edge:-edge, edge:-edge, slicesindex];
                else:
                    xData = data[:, :, slicesindex];
            elif direction==1:
                if edge>0:
                    xData = data[edge:-edge, slicesindex, edge:-edge];
                else:
                    xData = data[:, slicesindex, :];
            else:
                if edge>0:
                    xData = data[slicesindex, edge:-edge, edge:-edge];
                else:
                    xData = data[slicesindex, :, :];
            thick_s.append(xData)
            Label_s.append(Label_base[k])
            Age_s.append(Age_base[k])
            Gender_s.append(Gender_base[k])
            SubjIDIndex_sub_in_whole.append(SubjIDIndex_sub_in_whole_base[k])
            SubjIDIndex_sub_index.append(SubjIDIndex_sub_index_base[k])
            SubjID_s.append(SubjID[k])
            Viscode_s.append(Viscode[k])
            SliceID_s.append(slicesindex)
    thick_s = np.array(thick_s)
    thick_s = np.expand_dims(thick_s, axis=3)
#    thick_s = thickdata[select_index]
    Label_s = np.array(Label_s)
    Label_s[Label_s==label1] = 0
    Label_s[Label_s==label2] = 1
    
    SubjIDIndex_sub_in_whole = np.array(SubjIDIndex_sub_in_whole)
    SubjIDIndex_sub_index = np.array(SubjIDIndex_sub_index)
    Age_s = np.array(Age_s)
    Gender_s = np.array(Gender_s)
    SliceID_s = np.array(SliceID_s)
    return Label_s, SubjIDIndex_sub_in_whole, SubjIDIndex_sub_index, \
        thick_s, Age_s, Gender_s, SubjID_s, Viscode_s, SliceID_s, nlen, readnum          
def adni_set_class_define(Label, SubjidIndex):
    N = np.max(SubjidIndex)+1
    LabelSum = np.zeros(N, dtype=float)
    LabelNum = np.zeros(N, dtype=float)
    for i in range(len(Label)):
        LabelSum[SubjidIndex[i]] += Label[i]
        LabelNum[SubjidIndex[i]] += 1
    S = LabelSum/LabelNum
    C0 = np.array(np.where(S<0.5))[0]
    C1 = np.array(np.where(S>=0.5))[0]

    return C0, C1
def adni_tenfold(Label, SubjIDIndex, C0, C1, state, idx):
    if state < 0:
        C0 = shuffle(C0)
        C1 = shuffle(C1)
    else:
        C0 = shuffle(C0, random_state=state)
        C1 = shuffle(C1, random_state=state)
    NC0 = len(C0)
    PC0 = np.floor(NC0/10+0.8).astype(int)
    NC1 = len(C1)
    PC1 = np.floor(NC1/10+0.8).astype(int)
    if idx == 9:
        TestIdx  = np.concatenate((C0[PC0*9:NC0], C1[PC1*9:NC1]))
        TrainIdx = np.concatenate((C0[0:PC0*9], C1[0:PC1*9])) 
    else:
        TestIdx  = np.concatenate((C0[PC0*idx:PC0*(idx+1)], C1[PC1*idx:PC1*(idx+1)]))
        if idx == 0:
            TrainIdx = np.concatenate((C0[PC0:NC0], C1[PC1:NC1]))
        else:
            TrainIdx = np.concatenate((C0[0:PC0*idx], C0[PC0*(idx+1):NC0], C1[0:PC1*idx], C1[PC1*(idx+1):NC1]))
    TrainSet = [i for i,aa in enumerate(SubjIDIndex) if aa in TrainIdx]
    TestSet = [i for i,aa in enumerate(SubjIDIndex) if aa in TestIdx]
    return TrainIdx, TestIdx, TrainSet, TestSet


def adni_fivefold(Label, SubjIDIndex, C0, C1, state, idx):
    #state = 2
    if state < 0:
        C0 = shuffle(C0)
        C1 = shuffle(C1)
    else:
        C0 = shuffle(C0, random_state=state)
        C1 = shuffle(C1, random_state=3)#95524
    NC0 = len(C0)
    PC0 = np.floor(NC0/5+0.8).astype(int)
    NC1 = len(C1)
    PC1 = np.floor(NC1/5+0.8).astype(int)
    if idx == 9:
        TestIdx  = np.concatenate((C0[PC0*9:NC0], C1[PC1*9:NC1]))
        TrainIdx = np.concatenate((C0[0:PC0*9], C1[0:PC1*9]))
    else:
        TestIdx  = np.concatenate((C0[PC0*idx:PC0*(idx+1)], C1[PC1*idx:PC1*(idx+1)]))
        if idx == 0:
            TrainIdx = np.concatenate((C0[PC0:NC0], C1[PC1:NC1]))
        else:
            TrainIdx = np.concatenate((C0[0:PC0*idx], C0[PC0*(idx+1):NC0], C1[0:PC1*idx], C1[PC1*(idx+1):NC1]))
    TrainSet = [i for i,aa in enumerate(SubjIDIndex) if aa in TrainIdx]
    TestSet = [i for i,aa in enumerate(SubjIDIndex) if aa in TestIdx]
    return TrainIdx, TestIdx, TrainSet, TestSet


def train_valid_data(input_target, valid_ratio, TrainSet):
    num_subj = input_target.shape[0]
    TrainSet = np.array(TrainSet)

    num_control = np.sum(input_target[:, 0])
    num_patient = np.sum(input_target[:, 1])
    control_index_all = [i for i, aa in enumerate(input_target[:, 0]) if aa == 1]
    #control_valid_index = random.sample(control_index_all, int(math.floor(valid_ratio*num_control)))
    control_valid_index = control_index_all[0:int(math.floor(valid_ratio * num_control))]  # special case for subjets with multiple scans arranged side-by-side
    #print("control_valid_index")
    #print('Control_valid_index: ', control_valid_index)
    #print('Control_valid_index.shape: ', len(control_valid_index))
    patient_index_all = [i for i, aa in enumerate(input_target[:, 1]) if aa == 1]
    #    patient_valid_index = random.sample(patient_index_all, int(math.floor(valid_ratio*num_patient)))
    patient_valid_index = patient_index_all[0:int(
        math.floor(valid_ratio * num_patient))]  # special case for subjets with multiple scans arranged side-by-side


    data_valid_index = np.concatenate((control_valid_index, patient_valid_index), axis=0)
    data_valid_index = np.array(data_valid_index).astype(int)
    #print("data_valid_index:", data_valid_index)
    #print("data_valid_index.shape:", len(data_valid_index))
    #data_valid = input_data[data_valid_index, ...]
    target_valid = input_target[data_valid_index]

    # randomly sample a fixed ratio of control and patients to create training and validation sets
    data_train_index = np.delete(np.arange(num_subj), data_valid_index)
    #data_train = input_data[data_train_index, ...]
    #print("data_train_index:", data_train_index)
    target_train = input_target[data_train_index]

    train_s = TrainSet[data_train_index]
    valid_s = TrainSet[data_valid_index]
    #print("train_s:", train_s)
    print('Number of control: ', num_control)
    print('Number of patient: ', num_patient)

    #    return Bunch(data_train=data_train, target_train=target_train, data_valid=data_valid, target_valid=target_valid) # early prediction
    return  train_s, valid_s




def adni_get_subdata_only(Label, thick, TrainSet, TestSet):
    Label_test = Label[TestSet]
    Label_train = Label[TrainSet]
    #thick_test = thick[TestSet]
    #thick_train = thick[TrainSet]

    return Label_train, Label_test

#if __name__ == '__main__':
#    DATADIR = '/home/chaoqiang/user/imagenet3D2D/ADNI_3Ddata/'
#    listname = os.path.join(DATADIR,  'ADNI_filelist_Dec2019.csv')
#    imagepath = DATADIR
#    direction = 1
#    label1 = 0
#    label2 = 3
#    filepaths, Label, Age, Gender, study, SubjID, waveid = rflist._read_all_filelist(listname, ',')
#    thickdata=[]
#    for k in range(len(Label)):
#        filename = os.path.join(imagepath, filepaths[k]+'.nii.gz')
#        img = nib.load(filename)
##        print(img.shape)
#        data = img.get_data()
#        xData=np.mean(data,axis = direction)
#        thickdata.append(xData)
#    thickdata = np.array(thickdata)
#    select_index = [i for i,aa in enumerate(Label) if aa == label1 or aa == label2]
#    base_index   = [i for i,aa in enumerate(Label) if aa < label1]
#
#    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
#    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
#    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)
#    Label_s = Label[select_index]
#    Age_s   = Age[select_index]
#    Gender_s= Gender[select_index]
#    thick_s = thickdata[select_index]
#    if len(base_index)>0:
#        thick_base = thickdata[base_index]
#        Age_base = Age[base_index]
#        Gender_base = Gender[base_index]
#    else:
#        thick_base  = []
#        Age_base    = []
#        Gender_base = []
#    Label_s[Label_s==label1] = 0
#    Label_s[Label_s==label2] = 1
#if __name__ == '__main__':   
#    DATADIR = '/home/chaoqiang/user/imagenet3D2D/ADNI_3Ddata/'   
#    listname = os.path.join(DATADIR,  'ADNI_filelist_Jan2020.csv')
#    imagepath = DATADIR
##Label, SubjID, SubjIDIndex, thick_select, Age, Gender, thick_base, Age_base, Gender_base =\
##    adni_get_subset_3D2D(REG_thick_MAT, 0, 3, DATADIR, 0, training=1)
#    filepaths, Label, Age, Gender, study, SubjID, waveid, subjtype = rflist._read_all_filelist(listname, ',')
#    readnum = -1
#    training= 1
#    direction = 0
#    label1 = 0
#    label2 = 3
#    if readnum<= 0:
#        readnum = len(Label)
#    if readnum < len(Label):
#        filepaths = filepaths[0:readnum]
#        Label = Label[0:readnum]
#        Age = Age[0:readnum]
#        Gender = Gender[0:readnum]
#        study = study[0:readnum]
#        SubjID = SubjID[0:readnum]
#        waveid = waveid[0:readnum]
#        subjtype = subjtype[0:readnum]
##    thickdata=[]
#    for k in range(readnum):
#        filename = os.path.join(imagepath, filepaths[k]+'.nii.gz')
#        img = nib.load(filename)
##        print(img.shape)
#        data = img.get_data()
#        xData=np.mean(data,axis = direction)
#        thickdata.append(xData)
#    thickdata = np.array(thickdata)
#    thickdata = np.expand_dims(thickdata, axis=3)
#    select_index=[]
#    for i in range(len(Label)):
#        if training == 1:
#            if subjtype[i] == 0 and (Label[i] == label1 or Label[i] == label2):
#                select_index.append(i)
#        elif training == 0:
#            if subjtype[i] > 0 and (Label[i] == label1 or Label[i] == label2):
#                select_index.append(i)
#        else:
#            select_index.append(i)
#    base_index   = [i for i,aa in enumerate(Label) if aa < label1]
#
#    SubjIDIndex_in_whole = adni_generate_unique_SubjId(SubjID)
#    SubjIDIndex_sub_in_whole = SubjIDIndex_in_whole[select_index]
#    SubjIDIndex_sub_index = adni_generate_unique_SubjIdIndex(SubjIDIndex_sub_in_whole)
#    
#    Label_s = Label[select_index]
#    Age_s   = Age[select_index]
#    Gender_s= Gender[select_index]
#    
#    thick_s = []
#    for k in range(len(select_index)):
#        filename = os.path.join(imagepath, filepaths[select_index[k]]+'.nii.gz')
#        img = nib.load(filename)
###        print(img.shape)
#        data = img.get_data()
#        xData=np.mean(data,axis = direction)
#        thick_s.append(xData)
#    thick_s = np.array(thick_s)
#    thick_s = np.expand_dims(thick_s, axis=3)
##    thick_s = thickdata[select_index]
#    if len(base_index)>0:
#        thick_base = []#thickdata[base_index]
#        Age_base = Age[base_index]
#        Gender_base = Gender[base_index]
#    else:
#        thick_base  = []
#        Age_base    = []
#        Gender_base = []
#    Label_s[Label_s==label1] = 0
#    Label_s[Label_s==label2] = 1