"""
from .autoencoder import AutoEncoder, initialize_other_autoencoder, transfer_learning
from .iotools import iotools

#from .image_level import Conv5_FC3, Conv5_FC3_mni
from .patch_level import Conv4_FC3
#from .slice_level import resnet18
"""

def create_model(model_name, gpu=False, **kwargs):
    """
    Creates model object from the model_name.

    :param model_name: (str) the name of the model (corresponding exactly to the name of the class).
    :param gpu: (bool) if True a gpu is used.
    :return: (Module) the model object
    """

    try:
        model = eval(model_name)(**kwargs)
    except NameError:
        raise NotImplementedError('The model wanted %s has not been implemented.' % model_name)

    if gpu:
        model.cuda()
    else:
        model.cpu()

    return model



def init_model(model_name, autoencoder=False, gpu=False, **kwargs):

    model = create_model(model_name, gpu=gpu, **kwargs)
    """
    if autoencoder:
        model = AutoEncoder(model)
    """
    return model
