# coding: utf8

"""
Script containing the models for the patch level experiments.
"""
from torch import nn
from .modules import PadMaxPool3d, Flatten


class Conv4_FC3(nn.Module):
    """
    Classifier for a binary classification task

    Patch level architecture used on Minimal preprocessing

    This network is the implementation of this paper:
    'Multi-modality cascaded convolutional neural networks for Alzheimer's Disease diagnosis'
    """

    def __init__(self, dropout=0, n_classes=2):
        super(Conv4_FC3, self).__init__()

        self.features = nn.Sequential(
            # Convolutions
            nn.Conv3d(1, 15, 3),
            nn.BatchNorm3d(15),
            nn.ReLU(),
            PadMaxPool3d(2, 2),

            nn.Conv3d(15, 25, 3),
            nn.BatchNorm3d(25),
            nn.ReLU(),
            PadMaxPool3d(2, 2),

            nn.Conv3d(25, 50, 3),
            nn.BatchNorm3d(50),
            nn.ReLU(),
            PadMaxPool3d(2, 2),

            nn.Conv3d(50, 50, 3),
            nn.BatchNorm3d(50),
            nn.ReLU(),
            PadMaxPool3d(2, 2)

        )

        self.classifier0 = nn.Sequential(
            # Fully connected layers
            Flatten(),
        )

        self.classifier = nn.Sequential(
            # Fully connected layers
            nn.Dropout(p=dropout),
            #nn.Linear(50 * 2 * 2 * 2, 50),
            nn.Linear(50 * 1, 50),
            nn.ReLU(),
        )

        self.classifier2 = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(50, 40),
            nn.ReLU(),
            nn.Linear(40, n_classes)
        )



        #self.flattened_shape = [-1, 50, 2, 2, 2]
        self.flattened_shape = [-1, 50, 1]


    def forward(self, x):
        """
        x = self.features(x)
        x = self.classifier(x)

        return x
        """
        x = self.features(x)
        x = self.classifier0(x)
        #print("x.shape:", x.shape)
        x2 = x  # 此处为卷积层后输出的DATA
        #x2 = Flatten(x2)
        #print("before self.classifier(x) x.shape", x2.shape)
        x = self.classifier(x)
        #print("self.classifier(x) x.shape", x.shape)
        x = self.classifier2(x)
        #print("self.classifier2(x) x.shape", x.shape)

        #return x, x1, x2
        return  x2,x

