#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 15:39:46 2019

@author: chaoqiang
"""
import numpy as np

def _read_all_filelist_cn_ad_label(file, delimiter):
#   BEGIN

    f = open(file, "r")
    index = []
    Idx = [] #filename

    slices = [] #number
    Actual = [] #actual label
    Predicted = [] #predict label
    #dir_slice = []
    nFirst = 1

    for line in f:#B1
        tokens = line.split(delimiter)
        if nFirst<1:#B2
            if tokens[0] == "" or tokens == " ":
                continue
            else:
                index.append(tokens[0])
                Idx.append(tokens[1])
                #print(tokens[2])
                #direction.append(float(tokens[2]))
                slices.append(float(tokens[2]))
                Actual.append(float(tokens[3]))
                Predicted.append(float(tokens[4]))
                #dir_slice.append(tokens[2] + '_' + tokens[3])
        else:
            nFirst = 0;
        #E2
#        num = num+1
#        if num > 1024:
#            break
    #E1
    index = np.array(index)
    Idx = np.array(Idx)
    #direction = np.array(direction, dtype=float)
    slices = np.array(slices, dtype=float)
    Actual = np.array(Actual, dtype=float)
    Predicted = np.array(Predicted, dtype=float)
    return index, Idx, slices,Actual,Predicted


#Study	PTID_waves	Wave	Timepoint	DX	AGE	PTGENDER	PATH
def _read_all_filelist(file, delimiter):
#   BEGIN    
    f = open(file, "r")
    study = [] #0
    subjid = [] #1
    waveid = [] #3
    labels = []
    ages = []
    genders = []
    filepaths = []
    subjtype = []
    nFirst = 1;
#    num = 0;
    for line in f:#B1
        tokens = line.split(delimiter)
        if nFirst<1:#B2
            study.append(tokens[0])
            subjid.append(tokens[1])
            waveid.append(tokens[3])#tokens[2] is wave, 3 is viscode
            filepaths.append(tokens[0]+'_'+tokens[1]+'_'+tokens[2])
            dx = tokens[4]
            if dx == 'CN':
                labels.append(0)
            elif dx == 'EMCI':
                labels.append(2)
            elif dx == 'LMCI':
                labels.append(2)
            elif dx == 'MCI':
                labels.append(2)
            else:
                labels.append(3)
            ages.append(float(tokens[5]))
            genders.append(tokens[6]=='Male')
            subjtype.append(tokens[7])
        else:
            nFirst = 0;
        #E2
#        num = num+1
#        if num > 1024:
#            break
    #E1
    genders = np.array(genders, dtype=float)
    labels = np.array(labels, dtype=float)
    ages = np.array(ages, dtype=float)
    subjtype = np.array(subjtype, dtype=float)
    return filepaths, labels, ages, genders, study, subjid, waveid, subjtype
#END
def _read_sub_filelist(file, delimiter, dx1, dx2):
#   BEGIN    
    f = open(file, "r")
    study = [] #0
    subjid = [] #1
    waveid = [] #3
    labels = []
    ages = []
    genders = []
    filepaths = []
    nFirst = 1;
    for line in f:#B1
        tokens = line.split(delimiter)
        if nFirst<1:#B2
            dx = tokens[4]
            if dx == 'CN':
                dxx = 0
            elif dx == 'EMCI':
                dxx = 2
            elif dx == 'LMCI':
                dxx = 2
            elif dx == 'MCI':
                dxx = 2
            else:
                dxx = 3
            if ((dxx == dx1) | (dxx == dx2)):
                labels.append(3)
                study.append(tokens[0])
                subjid.append(tokens[1])
                waveid.append(tokens[2])
                filepaths.append(tokens[0]+'_'+tokens[1]+'_'+tokens[2])    
                ages.append(float(tokens[5]))
                genders.append(tokens[6]=='Male')
        else:
            nFirst = 0;
        #E2
    #E1
    genders = np.array(genders, dtype=float)
    labels = np.array(labels, dtype=float)
    ages = np.array(ages, dtype=float)
    return filepaths, labels, ages, genders, study, subjid, waveid
#END   
if __name__ == '__main__':   
    szpath = '/home/chaoqiang/user/ADNI_data/ADNI_filelist_Dec2019.csv'
#filepaths, labels, ages, genders, study, subjid, waveid = _read_all_filelist(szpath, ',')
    filepaths, labels, ages, genders, study, subjid, waveid = _read_sub_filelist(szpath, ',', 0, 3)