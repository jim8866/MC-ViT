#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  1 21:55:35 2022

@author: hufe
"""

from ADNI2_data_subset_new import get_result

output="/home/hufe/code/3d_patch/20211228_3d/3DCNN_mul3/result/result20211228118/fold-4/cnn_labels/selection/test_mode_cv5_level_label.csv"

get_result(output)