#from .models import create_autoencoder, create_model, load_model, load_optimizer, save_checkpoint
#from .iotools import read_json, commandline_to_json
from os import path
import torch
import torch
import os
import shutil

#from .autoencoder import AutoEncoder, initialize_other_autoencoder, transfer_learning
#from .iotools import load_model, load_optimizer, save_checkpoint
#from .image_level import Conv5_FC3, Conv5_FC3_mni
from .patch_level import Conv4_FC3
#from .resnet import resnet18
#from .slice_level import resnet18


def create_model(model_name, gpu=False, **kwargs):
    """
    Creates model object from the model_name.

    :param model_name: (str) the name of the model (corresponding exactly to the name of the class).
    :param gpu: (bool) if True a gpu is used.
    :return: (Module) the model object
    """

    try:
        model = eval(model_name)(**kwargs)
    except NameError:
        raise NotImplementedError(
            'The model wanted %s has not been implemented.' % model_name)
    #model = None

    return model


def create_autoencoder(model_name, gpu=False, transfer_learning_path=None, difference=0):
    """
    Creates an autoencoder object from the model_name.

    :param model_name: (str) the name of the model (corresponding exactly to the name of the class).
    :param gpu: (bool) if True a gpu is used.
    :param transfer_learning_path: (str) path to another pretrained autoencoder to perform transfer learning.
    :param difference: (int) difference of depth between the pretrained encoder and the new one.
    :return: (Module) the model object
    """
    from .autoencoder import AutoEncoder, initialize_other_autoencoder
    from os import path

    model = create_model(model_name, gpu)
    decoder = AutoEncoder(model)

    if transfer_learning_path is not None:
        if path.splitext(transfer_learning_path) != ".pth.tar":
            raise ValueError("The full path to the model must be given (filename included).")
        decoder = initialize_other_autoencoder(decoder, transfer_learning_path, difference)

    return decoder


def init_model(model_name, autoencoder=False, gpu=False, **kwargs):
    print("model:", model_name)
    #print("**kjwargs:", **kwargs)
    model = create_model(model_name, gpu=gpu, **kwargs)

    return model


class EarlyStopping(object):
    def __init__(self, mode='min', min_delta=0, patience=10):
        self.mode = mode
        self.min_delta = min_delta
        self.patience = patience
        self.best = None
        self.num_bad_epochs = 0
        self.is_better = None
        self._init_is_better(mode, min_delta)

        if patience == 0:
            self.is_better = lambda a, b: True
            self.step = lambda a: False

    def step(self, metrics):
        import numpy as np

        if self.best is None:
            self.best = metrics
            return False

        if np.isnan(metrics):
            return True

        if self.is_better(metrics, self.best):
            self.num_bad_epochs = 0
            self.best = metrics
        else:
            self.num_bad_epochs += 1

        if self.num_bad_epochs >= self.patience:
            return True

        return False

    def _init_is_better(self, mode, min_delta):
        if mode not in {'min', 'max'}:
            raise ValueError('mode ' + mode + ' is unknown!')

        if mode == 'min':
            self.is_better = lambda a, best: a < best - best * min_delta
        if mode == 'max':
            self.is_better = lambda a, best: a > best + best * min_delta

# coding: utf8

"""
Script containing the iotools for model and optimizer serialization.
"""


def save_checkpoint(state, accuracy_is_best, loss_is_best, checkpoint_dir, filename='checkpoint.pth.tar',
                    best_accuracy='best_balanced_accuracy', best_loss='best_loss'):


    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)

    torch.save(state, os.path.join(checkpoint_dir, filename))
    if accuracy_is_best:
        best_accuracy_path = os.path.join(checkpoint_dir, best_accuracy)
        if not os.path.exists(best_accuracy_path):
            os.makedirs(best_accuracy_path)
        shutil.copyfile(os.path.join(checkpoint_dir, filename),  os.path.join(best_accuracy_path, 'model_best.pth.tar'))

    if loss_is_best:
        best_loss_path = os.path.join(checkpoint_dir, best_loss)
        if not os.path.exists(best_loss_path):
            os.makedirs(best_loss_path)
        shutil.copyfile(os.path.join(checkpoint_dir, filename), os.path.join(best_loss_path, 'model_best.pth.tar'))


#def load_model(model, checkpoint_dir, gpu, filename='model_best.pth.tar'):
def load_model( checkpoint_dir, gpu, filename='model_best.pth.tar'):
    """
    Load the weights written in checkpoint_dir in the model object.

    :param model: (Module) CNN in which the weights will be loaded.
    :param checkpoint_dir: (str) path to the folder containing the parameters to loaded.
    :param gpu: (bool) if True a gpu is used.
    :param filename: (str) Name of the file containing the parameters to loaded.
    :return: (Module) the update model.
    """
    from copy import deepcopy#用copy模块下的deepcopy函数，防止元素被误改
    import torch
    import os

    #best_model = deepcopy(model)
    #param_dict = torch.load(os.path.join(checkpoint_dir, filename), map_location="cpu")
    param_dict = torch.load(os.path.join(checkpoint_dir, filename), map_location="cpu")
    #best_model.load_state_dict(param_dict['model'])
    #best_model.load_state_dict()
    #torch.load(param_dict)

    best_model = param_dict

    if gpu:
        best_model = best_model.cuda()

    return best_model#, param_dict['epoch']


def load_optimizer(optimizer_path, model):
    """
    Creates and load the state of an optimizer.

    :param optimizer_path: (str) path to the optimizer.
    :param model: (Module) model whom parameters will be optimized by the created optimizer.
    :return: optimizer initialized with specific state and linked to model parameters.
    """

    if not path.exists(optimizer_path):
        raise ValueError('The optimizer was not found at path %s' % optimizer_path)
    print('Loading optimizer')
    optimizer_dict = torch.load(optimizer_path)
    name = optimizer_dict["name"]
    optimizer = eval("torch.optim." + name)(filter(lambda x: x.requires_grad, model.parameters()))
    optimizer.load_state_dict(optimizer_dict["optimizer"])

