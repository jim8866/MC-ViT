# coding: utf8

import torch
import numpy as np
import os
import warnings
import pandas as pd
from time import time
from lib import ADNI2_data_subset_new as adni
import shutil

#from iotools import check_and_clean
#from util import EarlyStopping, save_checkpoint
from .util import EarlyStopping, save_checkpoint



#####################
# CNN train / test  #
#####################

def check_and_clean(d):
    import shutil
    import os

    if os.path.exists(d):
        shutil.rmtree(d)
    os.makedirs(d)

def test_get_data(model, data_train, label_train, file, num_valid, use_cuda, criterion, options, mode="image"):
    """
    Computes the predictions and evaluation metrics.

    Args:
        model: (Module) CNN to be tested.
        dataloader: (DataLoader) wrapper of a dataset.
        use_cuda: (bool) if True a gpu is used.
        criterion: (loss) function to calculate the loss.
        mode: (str) input used by the network. Chosen from ['image', 'patch', 'roi', 'slice'].
    Returns
        (DataFrame) results of each input.
        (dict) ensemble of metrics + total loss on mode level.
    """
    model.eval()#data_train, label_train
    """
    if mode == "image":
        columns = ["participant_id", "session_id", "true_label", "predicted_label"]
    elif mode in ["patch", "roi", "slice"]:
        columns = ['participant_id', 'session_id', '%s_id' % mode, 'true_label', 'predicted_label', 'proba0', 'proba1']
    else:
        raise ValueError("The mode %s is invalid." % mode)
    """
    softmax = torch.nn.Softmax(dim=1)
    #results_df = pd.DataFrame(columns=columns)
    total_loss = 0
    total_time = 0
    tend = time()
    print("options['batch_size']:", options['batch_size'])

    batch_size = int(options['batch_size'])
    with torch.no_grad():
        loss = 0
        size = data_train.shape[0]
        predictions = np.empty(size)
        logitss = np.empty((size, 2))
        logitss_soft = np.empty((size, 2))
        #fc_datas = np.empty((size, 50))
        fc_datas = np.empty((size, 400))
        #sess = self._get_session(sess)

        # tf.summary(sess)
        t0 = time()
        total_time = total_time + t0 - tend

        batch_data = np.zeros((batch_size, data_train.shape[1], data_train.shape[2], data_train.shape[3]))
        batch_labels = np.zeros(batch_size)
        logitss_s = np.zeros((batch_size, 2))
        soft_label = np.zeros((batch_size, 2))
        #batch_data = np.zeros((self.batch_size, data.shape[1], data.shape[2], data.shape[3]))
        for begin in range(0, size, batch_size):
            if type(batch_data) == torch.Tensor:

                #batch_data = batch_data.cpu().numpy()
                #batch_labels = batch_labels.cpu().numpy()
                batch_data = np.zeros((batch_size, data_train.shape[1], data_train.shape[2], data_train.shape[3]))
                batch_labels = np.zeros(batch_size)
                logitss_s = np.zeros((batch_size, 2))
                soft_label = np.zeros((batch_size, 2))
            #print("logitss.shape:", logitss_s.shape)

            end = begin + batch_size
            end = min([end, size])

            #batch_data = np.zeros((batch_size, data.shape[1], data.shape[2], data.shape[3]))
            tmp_data = data_train[begin:end, ...]

            batch_data[:end - begin] = tmp_data
            #feed_dict = {self.ph_data: batch_data, self.ph_dropout: 1}

            """
            import torchvision.transforms as tfs
            im_tfs = tfs.Compose([
                tfs.ToTensor(),
                tfs.Normalize(mean=0, std=1)
            ])
            batch_data = im_tfs(batch_data)
            """
            #batch_data = 2 * (batch_data / 255.) - 1#normilization
            batch_data = 2 * (batch_data / 255.) - 1

            batch_data = torch.tensor(batch_data).float()
            batch_data = torch.unsqueeze(batch_data, dim=1)

            inputs = batch_data.cuda()#

            #print("image.max:", inputs.argmax(dim=1))

            batch_labels[:end - begin] = label_train[begin:end]
            batch_labels = torch.tensor(batch_labels)
            batch_labels = batch_labels.cuda()

            labels = torch.nn.functional.one_hot(batch_labels.unsqueeze(0).to(torch.int64), options['classes'])
            #print("after labels:", labels)
            #print("labels.shape:", labels.size())
            labels = torch.squeeze(labels, dim=0)
            labels = labels.float()

            #outputs_data_fc,  outputs , outputs_data_cnn = model(inputs)
            outputs_data_fc,  outputs = model(inputs)
            logitss_s = outputs
            print("outputs_data_fc.shape:", outputs_data_fc.shape)
            #print("outputs_data_cnn.shape:", outputs_data_cnn.shape)

            loss = criterion(outputs, labels)
            #total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            #print("outputs.data:", outputs.data.cpu())
            soft_label = torch.softmax(outputs, dim=1)#dim=0在列上进行softmax，dim=1在行上进行softmax
            #print("soft_label:", soft_label.cpu())
            #os.exit(0)


            predicted = predicted.cpu()
            pre = predicted.numpy()
            predictions[begin:end] = pre[:end - begin]
            total_loss += loss.item()
            tend = time()
            logitss_s = logitss_s.cpu()
            outputs_data_fc = outputs_data_fc.cpu()
            #print("outputs_data_fc:", outputs_data_fc[0:200])
            #outputs_data_cnn = outputs_data_cnn.cpu()
            soft_label = soft_label.cpu()

            fc_datas[begin:end, ...] = outputs_data_fc[:end - begin, ...]
            #cnn_datas[begin:end, ...] = outputs_data_cnn[:end - begin, ...]
            logitss[begin:end, ...] = logitss_s[:end - begin, ...]
            logitss_soft [begin:end, ...] = soft_label[:end - begin, ...]

            #cnn_datas

            #print("fc_data.shape:", fc_datas.shape)
            #print("cnn_data.shape:", cnn_datas.shape)

        #print('Mean time per batch loading (test):', total_time / (data_train.shape[0] / batch_size))
        #results_df.reset_index(inplace=True, drop=True)

        # calculate the balanced accuracy
        results = evaluate_prediction(label_train.astype(int), predictions.astype(int))

        #results['total_loss'] = total_loss
        print("logits.shape", logitss.shape)
        label_results = {'pred': predictions,
                   'label': label_train,
                   'file': file,
                    'num':num_valid,
                    'logitss':logitss,
                    'logitss_soft':logitss_soft
                   }

        torch.cuda.empty_cache()

        print("reslults:", results)

    return results, label_results, fc_datas#, cnn_datas#, logitss




#train(model, data_train, label_train,file_train,num_train, data_valid, label_valid,num_valid, file_valid, criterion, optimizer, scheduler, False, log_dir, model_dir, params)
def train(model, data_train, label_train, file_train, num_train, data_valid, label_valid, num_valid, file_valid, criterion, optimizer, scheduler, resume, log_dir, model_dir, options):
    """
    Function used to train a CNN.
    The best model and checkpoint will be found in the 'best_model_dir' of options.output_dir.

    Args:
        model: (Module) CNN to be trained
        train_loader: (DataLoader) wrapper of the training dataset
        valid_loader: (DataLoader) wrapper of the validation dataset
        criterion: (loss) function to calculate the loss
        optimizer: (torch.optim) optimizer linked to model parameters
        resume: (bool) if True, a begun job is resumed
        log_dir: (str) path to the folder containing the logs
        model_dir: (str) path to the folder containing the models weights and biases
        options: (Namespace) ensemble of other options given to the main script.
    """
    from tensorboardX import SummaryWriter
    from time import time

    if not resume:
        check_and_clean(model_dir)
        check_and_clean(log_dir)

    # Create writers
    writer_train = SummaryWriter(os.path.join(log_dir, 'train'))
    writer_valid = SummaryWriter(os.path.join(log_dir, 'validation'))

    #print("options.key:", options.key())

    # Initialize variables
    best_valid_accuracy = 0.0
    best_valid_loss = np.inf
    epoch = options['beginning_epoch']

    model.train()  # set the module to training mode

    #early_stopping = EarlyStopping('min', min_delta=options['tolerance'], patience=options['patience'])
    mean_loss_valid = None
    fi = options['foldIDS']

    max_gmean = -1.0

    step_list = []
    train_loss_list = []
    train_accuracy_list = []
    train_fscore_list = []
    train_sensitivity_list = []
    train_specificity_list = []
    train_precision_list = []
    train_ppv_list = []
    train_npv_list = []
    train_gmean_list = []

    val_loss_list = []
    val_accuracy_list = []
    val_fscore_list = []
    val_sensitivity_list = []
    val_specificity_list = []
    val_precision_list = []
    val_ppv_list = []
    val_npv_list = []
    val_gmean_list = []
    max_gmean = -1

    #while epoch < options['epoch'] and not early_stopping.step(mean_loss_valid):
    while epoch < options['epoch']:
        print("At %d-th epoch." % epoch)

        model.zero_grad()
        evaluation_flag = True
        step_flag = True
        tend = time()
        total_time = 0

        #for i, data in enumerate(train_loader, 0):
        for i in np.arange(options['num_batch']):
            t0 = time()
            total_time = total_time + t0 - tend
            """
            if options.gpu:
                imgs, labels = data['image'].cuda(), data['label'].cuda()
            else:
                imgs, labels = data['image'], data['label']
            """
            #(train_data, train_labels, batch_size, patient_ratio, random_batch_sampling_train=False):
            #print("in data_train:", data_train)

            imgs, labels = adni.generate_train_batch(data_train, label_train, options['batch_size'], options['patient_ratio'])

            """
            import torchvision.transforms as tfs
            im_tfs = tfs.Compose([
                tfs.ToTensor(),
                tfs.Normalize(mean=0, std=1)
            ])
            imgs = im_tfs(imgs)
            """

            imgs = 2 * (imgs / 255.) - 1#normilization
            #print("np.max(imgs):", np.max(imgs))
            #print("np.min(imgs):", np.min(imgs))

            image = torch.tensor(imgs).float()
            label = torch.tensor(labels)
            if options['gpu']:
                imgs, labels = image.cuda(), label.cuda()
            else:
                imgs, labels = image, label
            labels = labels.to(dtype=torch.int64).cuda()
            imgs = torch.unsqueeze(imgs, dim=1)
            """
            #print("before labels:", labels)
            labels = torch.nn.functional.one_hot(labels.unsqueeze(0).to(torch.int64), options['classes'])
            #print("after labels:", labels)
            #print("labels.shape:", labels.size())
            labels = torch.squeeze(labels, dim=0)
            labels = labels.float()
            #print("after2 labels:", labels)
            #print("labels.shape:", labels.size())

            #print("before imgs.size:", imgs.size())
            imgs = torch.unsqueeze(imgs, dim=1)
            #print("after imgs.size:", imgs.size())
            """
            #train_output, train_output_data_fc, train_output_data_cnn = model(imgs)
            out_feature, train_output = model(imgs)
            #print("train_output_data_fc.shape:", train_output_data_fc.shape)
            #print("train_output_data_cnn.shape:", train_output_data_cnn.shape)
            

            _, predict_batch = train_output.topk(1)
            loss = criterion(train_output, labels)
            print("folder:", fi,"epoch:", epoch, ",step:", i, "loss:", loss.item(), "lr:", optimizer.param_groups[0]['lr'])

            # Back propagation
            loss.backward()

            del imgs, labels

            if (i + 1) % options['accumulation_steps'] == 0:
                step_flag = False
                optimizer.step()
                optimizer.zero_grad()
                #model.zero_grad()

                del loss

                # Evaluate the model only when no gradients are accumulated
                if options['num_batch'] != 0 and (i + 1) % (options['num_batch']) == 0:
                    evaluation_flag = False
                    print('Iteration %d' % i)

                    results_train, label_results_train = test(model, data_train, label_train, file_train, num_train, options['gpu'], criterion, options)
                    mean_loss_train = results_train["total_loss"] / float(options['num_batch'] + 1)

                    results_valid, label_results_valid = test(model, data_valid, label_valid,file_valid, num_valid, options['gpu'], criterion, options)
                    mean_loss_valid = results_valid["total_loss"] / float(options['num_batch'] + 1)
                    model.train()#训练过程中会在程序上方添加一句model.train()，作用是启用batch normalization和drop out





                    """
                    global_step = i + epoch * data_train.shape[0]
                    writer_train.add_scalar('balanced_accuracy', results_train["balanced_accuracy"], global_step)
                    writer_train.add_scalar('loss', mean_loss_train, global_step)
                    writer_valid.add_scalar('balanced_accuracy', results_valid["balanced_accuracy"], global_step)
                    writer_valid.add_scalar('loss', mean_loss_valid, global_step)
                    """
                    """
                    print("%s level training accuracy is %f at the end of iteration %d"
                          % (options.mode, results_train["balanced_accuracy"], i))
                    print("%s level validation accuracy is %f at the end of iteration %d"
                          % (options.mode, results_valid["balanced_accuracy"], i))
                    """
                    """
                        results = {'accuracy': accuracy,
                       'balanced_accuracy': balanced_accuracy,
                       'sensitivity': sensitivity,
                       'specificity': specificity,
                       'ppv': ppv,
                       'npv': npv,
               }
                    
                    """



            tend = time()

        print('Mean time per batch loading (train):', total_time / options['num_batch'])

        """
        # If no step has been performed, raise Exception
        if step_flag:
            raise Exception('The model has not been updated once in the epoch. The accumulation step may be too large.')

        # If no evaluation has been performed, warn the user
        elif evaluation_flag and options.evaluation_steps != 0:
            warnings.warn('Your evaluation steps are too big compared to the size of the dataset.'
                          'The model is evaluated only once at the end of the epoch')
        """
        # Always test the results and save them once at the end of the epoch
        model.zero_grad()


        results_train, label_results_train = test(model, data_train, label_train, file_train, num_train, options['gpu'], criterion, options)
        mean_loss_train = results_train["total_loss"] / float(options['num_batch'] + 1)

        results_valid, label_results_valid = test(model, data_valid, label_valid, file_valid, num_valid, options['gpu'], criterion, options)
        mean_loss_valid = results_valid["total_loss"] / float(options['num_batch'] + 1)

        #保存model
        gmean_train = results_train['gmean']
        gmean_valid = results_valid['gmean']

        gmean_valid_new = min(gmean_valid, gmean_train)
        if gmean_valid_new > max_gmean:
            if not os.path.exists(model_dir):
                os.makedirs(model_dir)
            max_gmean = gmean_valid_new
            #print("os.path.join(model_dir, "filename")")
            #shutil.copyfile(os.path.join(model_dir, "filename"), os.path.join("best", 'model_best.pth.tar'))
            #torch.save(model.state_dict(), os.path.join(model_dir, "model_best.pth.tar"))
            #torch.save(optimizer.state_dict(), os.path.join(model_dir, "optimizer.pth.tar"))
            torch.save(model, os.path.join(model_dir, "model_best.pth.tar"))
            print('Last checkpoint at the end of the epoch %d' % epoch)
            """
            save_checkpoint({'model': model.state_dict(),
                             'epoch': epoch,
                             'valid_loss': mean_loss_valid,
                             'valid_acc': results_valid["balanced_accuracy"]},
                            gmean_valid,
                            model_dir)
            # Save optimizer state_dict to be able to reload
            save_checkpoint({'optimizer': optimizer.state_dict(),
                             'epoch': epoch,
                             'name': options['optimizer'],
                             },
                            False, False,
                            model_dir,
                            filename='optimizer.pth.tar')
            """
            # self.op_saver.save(sess, path, write_state=True, global_step=step)
        else:
            max_gmean = max_gmean * 0.99995

        """
        _, results_train = test(model, train_loader, options.gpu, criterion)
        mean_loss_train = results_train["total_loss"] / (len(train_loader) * train_loader.batch_size)

        _, results_valid = test(model, valid_loader, options.gpu, criterion)
        mean_loss_valid = results_valid["total_loss"] / (len(valid_loader) * valid_loader.batch_size)
        """
        scheduler.step(mean_loss_valid)
        #lr = scheduler.get_lr()[0]
        #scheduler.get_lr()

        global_step = (epoch + 1) * options['num_batch']

        step_list.append(global_step)
        train_accuracy_list.append(results_train["balanced_accuracy"])
        # train_fscore_list.append(fscore_train)
        train_sensitivity_list.append(results_train["sensitivity"])
        train_specificity_list.append(results_train["specificity"])
        # train_precision_list.append(precision_train)
        train_ppv_list.append(results_train["ppv"])
        train_npv_list.append(results_train["npv"])
        train_loss_list.append(mean_loss_train)
        train_gmean_list.append(results_train["gmean"])

        val_accuracy_list.append(results_valid["balanced_accuracy"])
        # train_fscore_list.append(fscore_train)
        val_sensitivity_list.append(results_valid["sensitivity"])
        val_specificity_list.append(results_valid["specificity"])
        # train_precision_list.append(precision_train)
        val_ppv_list.append(results_valid["ppv"])
        val_npv_list.append(results_valid["npv"])
        val_gmean_list.append(results_valid["gmean"])
        val_loss_list.append(mean_loss_valid)

        # print( '%s: ' % datetime.now())
        print('corss_valid: {} ,step: {} / {} (epoch: {:.2f} / {}):'.format(fi, i, global_step, int(epoch),
                                                                            options['epoch']))
        # print('learning_rate = {:.2e}, loss_average = {:.2e}'.format(learning_rate, loss_average))
        format_str = ('%.1f examples/sec; %.3f ' 'sec/batch')
        # print("wd:", wd)
        # print( format_str % (examples_per_sec, sec_per_batch))
        # print( 'Prevalence = %.4f' % prevalence)
        print("learning_rate:", optimizer.param_groups[0]['lr'])
        print('Train loss = %.4f' % mean_loss_train)
        print('Train top1 accuracy = %.4f' % results_train["balanced_accuracy"])
        print('Train top1 sensitivity = %.4f' % results_train["sensitivity"])
        print('Train top1 specificity = %.4f' % results_train["specificity"])
        print('Train top1 ppv = %.4f' % results_train["ppv"])
        print('Train top1 npv = %.4f' % results_train["npv"])
        # print( 'Train top1 ppv = %.4f' % results_train["balanced_accuracy"])
        # print( 'Train top1 npv = %.4f' % results_train["balanced_accuracy"])
        # print( 'Train top1 gmean = %.4f' % results_train["balanced_accuracy"])
        print('*******')
        print('Validation loss = %.4f' % mean_loss_valid)
        print('Validation top1 accuracy = %.4f' % results_valid["balanced_accuracy"])
        print('Validation top1 sensitivity = %.4f' % results_valid["sensitivity"])
        print('Validation top1 specificity= %.4f' % results_valid["specificity"])
        print('Validation top1 ppv = %.4f' % results_valid["ppv"])
        print('Validation top1 npv = %.4f' % results_valid["npv"])
        # print( 'Validation top1 ppv = %.4f' % results_valid["balanced_accuracy"])
        # print( 'Validation top1 npv = %.4f' % results_valid["balanced_accuracy"])
        # print( 'Validation top1 gmean = %.4f' % results_valid["balanced_accuracy"])
        print('----------------------------')

        df = pd.DataFrame(
            data={'step': step_list, 'train_accuracy': train_accuracy_list, 'train_sensitivity': train_sensitivity_list,
                  'train_specificity': train_specificity_list, 'train_ppv': train_ppv_list, 'train_npv': train_npv_list,
                  'train_loss': train_loss_list,
                  'validation_accuracy': val_accuracy_list, 'validation_sensitivity': val_sensitivity_list,
                  'validation_specificity': val_specificity_list,
                  'validation_ppv': val_ppv_list, 'validation_npv': val_npv_list, 'valid_loss': val_loss_list,
                  "val_gmean": val_gmean_list, "train_gmean": train_gmean_list})

        performance_dir = os.path.join(options['output_dir'], 'fold-%i' % options['foldIDS'], 'perfermance.csv')
        df.to_csv(performance_dir)



        model.train()

        #global_step = (epoch + 1) * len(train_loader)
        global_step = (epoch + 1) * options['num_batch']
        writer_train.add_scalar('balanced_accuracy', results_train["balanced_accuracy"], global_step)
        writer_train.add_scalar('loss', mean_loss_train, global_step)
        writer_valid.add_scalar('balanced_accuracy', results_valid["balanced_accuracy"], global_step)
        writer_valid.add_scalar('loss', mean_loss_valid, global_step)
        """
        print("%s level training accuracy is %f at the end of iteration %d"
              % (options.mode, results_train["balanced_accuracy"], data_train.shape[0]))
        print("%s level validation accuracy is %f at the end of iteration %d"
              % (options.mode, results_valid["balanced_accuracy"], data_train.shape[0]))
        
        accuracy_is_best = results_valid["balanced_accuracy"] > best_valid_accuracy
        loss_is_best = mean_loss_valid < best_valid_loss
        best_valid_accuracy = max(results_valid["balanced_accuracy"], best_valid_accuracy)
        best_valid_loss = min(mean_loss_valid, best_valid_loss)

        save_checkpoint({'model': model.state_dict(),
                         'epoch': epoch,
                         'valid_loss': mean_loss_valid,
                         'valid_acc': results_valid["balanced_accuracy"]},
                        accuracy_is_best, loss_is_best,
                        model_dir)
        # Save optimizer state_dict to be able to reload
        save_checkpoint({'optimizer': optimizer.state_dict(),
                         'epoch': epoch,
                         'name': options['optimizer'],
                         },
                        False, False,
                        model_dir,
                        filename='optimizer.pth.tar')
        """
        epoch += 1

    #os.remove(os.path.join(model_dir, "optimizer.pth.tar"))
    #os.remove(os.path.join(model_dir, "checkpoint.pth.tar"))
    return model


def evaluate_prediction(y, y_pred):
    """
    Evaluates different metrics based on the list of true labels and predicted labels.

    Args:
        y: (list) true labels
        y_pred: (list) corresponding predictions

    Returns:
        (dict) ensemble of metrics
    """

    true_positive = np.sum((y_pred == 1) & (y == 1))
    true_negative = np.sum((y_pred == 0) & (y == 0))
    false_positive = np.sum((y_pred == 1) & (y == 0))
    false_negative = np.sum((y_pred == 0) & (y == 1))

    accuracy = (true_positive + true_negative) / (true_positive + true_negative + false_positive + false_negative)

    if (true_positive + false_negative) != 0:
        sensitivity = true_positive / (true_positive + false_negative)
    else:
        sensitivity = 0.0

    if (false_positive + true_negative) != 0:
        specificity = true_negative / (false_positive + true_negative)
    else:
        specificity = 0.0

    if (true_positive + false_positive) != 0:
        ppv = true_positive / (true_positive + false_positive)
    else:
        ppv = 0.0

    if (true_negative + false_negative) != 0:
        npv = true_negative / (true_negative + false_negative)
    else:
        npv = 0.0

    balanced_accuracy = (sensitivity + specificity) / 2

    gmean = np.sqrt(np.multiply(sensitivity, specificity))

    results = {'accuracy': accuracy,
               'balanced_accuracy': balanced_accuracy,
               'sensitivity': sensitivity,
               'specificity': specificity,
               'ppv': ppv,
               'npv': npv,
               'gmean': gmean
               }

    return results

#test(model, data_valid, label_valid, file_valid, num_valid, options['gpu'], criterion, options)
def test(model, data_train, label_train, file, num_valid, use_cuda, criterion, options, mode="image"):
    """
    Computes the predictions and evaluation metrics.

    Args:
        model: (Module) CNN to be tested.
        dataloader: (DataLoader) wrapper of a dataset.
        use_cuda: (bool) if True a gpu is used.
        criterion: (loss) function to calculate the loss.
        mode: (str) input used by the network. Chosen from ['image', 'patch', 'roi', 'slice'].
    Returns
        (DataFrame) results of each input.
        (dict) ensemble of metrics + total loss on mode level.
    """
    model.eval()#data_train, label_train
    """
    if mode == "image":
        columns = ["participant_id", "session_id", "true_label", "predicted_label"]
    elif mode in ["patch", "roi", "slice"]:
        columns = ['participant_id', 'session_id', '%s_id' % mode, 'true_label', 'predicted_label', 'proba0', 'proba1']
    else:
        raise ValueError("The mode %s is invalid." % mode)
    """
    softmax = torch.nn.Softmax(dim=1)
    #results_df = pd.DataFrame(columns=columns)
    total_loss = 0
    total_time = 0
    tend = time()
    print("options['batch_size']:", options['batch_size'])

    batch_size = int(options['batch_size'])
    with torch.no_grad():
        loss = 0
        size = data_train.shape[0]
        predictions = np.empty(size)
        logitss = np.empty((size, 2))
        #fc_datas = np.empty((size, 2048))
        #sess = self._get_session(sess)

        # tf.summary(sess)
        t0 = time()
        total_time = total_time + t0 - tend

        batch_data = np.zeros((batch_size, data_train.shape[1], data_train.shape[2], data_train.shape[3]))
        batch_labels = np.zeros(batch_size)
        #batch_data = np.zeros((self.batch_size, data.shape[1], data.shape[2], data.shape[3]))
        for begin in range(0, size, batch_size):
            if type(batch_data) == torch.Tensor:

                #batch_data = batch_data.cpu().numpy()
                #batch_labels = batch_labels.cpu().numpy()
                batch_data = np.zeros((batch_size, data_train.shape[1], data_train.shape[2], data_train.shape[3]))
                batch_labels = np.zeros(batch_size)

            end = begin + batch_size
            end = min([end, size])

            #batch_data = np.zeros((batch_size, data.shape[1], data.shape[2], data.shape[3]))
            tmp_data = data_train[begin:end, ...]

            batch_data[:end - begin] = tmp_data
            #feed_dict = {self.ph_data: batch_data, self.ph_dropout: 1}

            """
            import torchvision.transforms as tfs
            im_tfs = tfs.Compose([
                tfs.ToTensor(),
                tfs.Normalize(mean=0, std=1)
            ])
            batch_data = im_tfs(batch_data)
            """
            #batch_data = 2 * (batch_data / 255.) - 1#normilization
            batch_data = 2 * (batch_data / 255.) - 1
            #print("np.max(batch_data):", np.max(batch_data))
            #print("np.min(batch_data):", np.min(batch_data))

            batch_data = torch.tensor(batch_data).float()
            batch_data = torch.unsqueeze(batch_data, dim=1)

            inputs = batch_data.cuda()#




            #print("image.max:", inputs.argmax(dim=1))

            batch_labels[:end - begin] = label_train[begin:end]
            batch_labels = torch.tensor(batch_labels)
            batch_labels = batch_labels.cuda()

            """
            labels = torch.nn.functional.one_hot(batch_labels.unsqueeze(0).to(torch.int64), options['classes'])
            #print("after labels:", labels)
            #print("labels.shape:", labels.size())
            labels = torch.squeeze(labels, dim=0)
            labels = labels.float()
            """
            
            labels = batch_labels.to(dtype=torch.int64).cuda()
            #outputs, outputs_data_fc, outputs_data_cnn = model(inputs)
            out_feature, outputs = model(inputs)
            loss = criterion(outputs, labels)
            #total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)

            predicted = predicted.cpu()
            pre = predicted.numpy()
            predictions[begin:end] = pre[:end - begin]
            total_loss += loss.item()
            tend = time()



        """

        for i, data in enumerate(dataloader, 0):

            t0 = time()
            total_time = total_time + t0 - tend
            if use_cuda:
                inputs, labels = data['image'].cuda(), data['label'].cuda()
            else:
                inputs, labels = data['image'], data['label']
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)

            # Generate detailed DataFrame
            for idx, sub in enumerate(data['participant_id']):
                if mode == "image":
                    row = [[sub, data['session_id'][idx], labels[idx].item(), predicted[idx].item()]]
                else:
                    normalized_output = softmax(outputs)
                    row = [[sub, data['session_id'][idx], data['%s_id' % mode][idx].item(),
                            labels[idx].item(), predicted[idx].item(),
                            normalized_output[idx, 0].item(), normalized_output[idx, 1].item()]]

                row_df = pd.DataFrame(row, columns=columns)
                results_df = pd.concat([results_df, row_df])

            del inputs, outputs, labels, loss
            tend = time()
        """
        print('Mean time per batch loading (test):', total_time / (data_train.shape[0] / batch_size))
        #results_df.reset_index(inplace=True, drop=True)

        # calculate the balanced accuracy
        results = evaluate_prediction(label_train.astype(int), predictions.astype(int))
        #results_df.reset_index(inplace=True, drop=True)
        results['total_loss'] = total_loss

        label_results = {'pred': predictions,
                   'label': label_train,
                   'file': file,
                    'num':num_valid
                   }
        """
        results['pred'] = predictions
        results['label'] = label_train
        results['file'] = file
        """
        torch.cuda.empty_cache()

    return results, label_results


#################################
# Voting systems
#################################

def mode_level_to_tsvs(output_dir, results_df, metrics, fold, selection, mode, dataset='train', cnn_index=None):
    """
    Writes the outputs of the test function in tsv files.

    Args:
        output_dir: (str) path to the output directory.
        results_df: (DataFrame) the individual results per patch.
        metrics: (dict or DataFrame) the performances obtained on a series of metrics.
        fold: (int) the fold for which the performances were obtained.
        selection: (str) the metrics on which the model was selected (best_acc, best_loss)
        mode: (str) input used by the network. Chosen from ['image', 'patch', 'roi', 'slice'].
        dataset: (str) the dataset on which the evaluation was performed.
        cnn_index: (int) provide the cnn_index only for a multi-cnn framework.
    """
    if cnn_index is None:
        performance_dir = os.path.join(output_dir, 'fold-%i' % fold, 'cnn_classification', selection)
    else:
        performance_dir = os.path.join(output_dir, 'fold-%i' % fold, 'cnn_classification', 'cnn-%i' % cnn_index,
                                       selection)
        metrics["%s_id" % mode] = cnn_index
    print("performance_dir:", performance_dir)
    if not os.path.exists(performance_dir):
        os.makedirs(performance_dir)
    """
    results_df.to_csv(os.path.join(performance_dir, '%s_%s_level_prediction.csv' % (dataset, mode)), index=False,
                      sep='\t')
    """
    if isinstance(metrics, dict):
        pd.DataFrame(metrics, index=[0]).to_csv(os.path.join(performance_dir, '%s_%s_level_metrics.csv' % (dataset, mode)),
                                                index=False, sep='\t')
    elif isinstance(metrics, pd.DataFrame):
        metrics.to_csv(os.path.join(performance_dir, '%s_%s_level_metrics.csv' % (dataset, mode)),
                       index=False, sep='\t')
    else:
        raise ValueError("Bad type for metrics: %s. Must be dict or DataFrame." % type(metrics).__name__)
    return performance_dir


def label_mode_level_to_tsvs(output_dir, results_df, metrics, fold, selection, mode, dataset='train', label=None):
    """
    Writes the outputs of the test function in tsv files.

    Args:
        output_dir: (str) path to the output directory.
        results_df: (DataFrame) the individual results per patch.
        metrics: (dict or DataFrame) the performances obtained on a series of metrics.
        fold: (int) the fold for which the performances were obtained.
        selection: (str) the metrics on which the model was selected (best_acc, best_loss)
        mode: (str) input used by the network. Chosen from ['image', 'patch', 'roi', 'slice'].
        dataset: (str) the dataset on which the evaluation was performed.
        cnn_index: (int) provide the cnn_index only for a multi-cnn framework.
    """
    if label is None:
        performance_dir = os.path.join(output_dir, 'fold-%i' % fold, 'cnn_labels', selection)
    else:
        performance_dir = os.path.join(output_dir, 'fold-%i' % fold, 'cnn_labels', 'cnn-%i' % label, selection)
        metrics["%s_id" % mode] = label

    if not os.path.exists(performance_dir):
        os.makedirs(performance_dir)
    """
    results_df.to_csv(os.path.join(performance_dir, '%s_%s_level_prediction.csv' % (dataset, mode)), index=False,
                      sep='\t')
    label_results = {'pred': predictions,
       'label': label_train,
       'file': file
       }
    """
    dir_name = os.path.join(performance_dir, '%s_%s_level_label.csv' % (dataset, mode))
    dir_name1 = os.path.join(performance_dir, '%s_%s_level_label.csv' % (dataset, mode))
    #idx = np.arange(metrics["file"])
    #df_label = pd.DataFrame(data=d, dtype=np.uint16)
    df = {'file': metrics["file"], 'number':metrics['num'], 'label': metrics["label"], 'prediction': metrics["pred"]}
    df = pd.DataFrame(data=df)
    df.to_csv(dir_name)
    return dir_name


    #pd.DataFrame(metrics).to_csv(os.path.join(performance_dir, '%s_%s_level_metrics.csv' % (dataset, mode)), index=False, sep='\t')
    """
    if isinstance(metrics, dict):
        pd.DataFrame(metrics, index=[0]).to_csv(os.path.join(performance_dir, '%s_%s_level_metrics.csv' % (dataset, mode)), index=False, sep='\t')
    elif isinstance(metrics, pd.DataFrame):
        metrics.to_csv(os.path.join(performance_dir, '%s_%s_level_metrics.csv' % (dataset, mode)), index=False, sep='\t')
    else:
        raise ValueError("Bad type for metrics: %s. Must be dict or DataFrame." % type(metrics).__name__)
    """



def concat_multi_cnn_results(output_dir, fold, selection, mode, dataset, num_cnn):
    """Concatenate the tsv files of a multi-CNN framework"""
    prediction_df = pd.DataFrame()
    metrics_df = pd.DataFrame()
    for cnn_index in range(num_cnn):
        cnn_dir = os.path.join(output_dir, 'fold-%i' % fold, 'cnn_classification', 'cnn-%i' % cnn_index)
        performance_dir = os.path.join(cnn_dir, selection)
        cnn_pred_path = os.path.join(performance_dir, '%s_%s_level_prediction.tsv' % (dataset, mode))
        cnn_metrics_path = os.path.join(performance_dir, '%s_%s_level_metrics.tsv' % (dataset, mode))

        cnn_pred_df = pd.read_csv(cnn_pred_path, sep='\t')
        cnn_metrics_df = pd.read_csv(cnn_metrics_path, sep='\t')
        prediction_df = pd.concat([prediction_df, cnn_pred_df])
        metrics_df = pd.concat([metrics_df, cnn_metrics_df])

        # Clean unused files
        os.remove(cnn_pred_path)
        os.remove(cnn_metrics_path)
        if len(os.listdir(performance_dir)) == 0:
            os.rmdir(performance_dir)
        if len(os.listdir(cnn_dir)) == 0:
            os.rmdir(cnn_dir)

    prediction_df.reset_index(drop=True, inplace=True)
    metrics_df.reset_index(drop=True, inplace=True)
    mode_level_to_tsvs(output_dir, prediction_df, metrics_df, fold, selection, mode, dataset)


def retrieve_sub_level_results(output_dir, fold, selection, mode, dataset, num_cnn):
    """Retrieve performance_df for single or multi-CNN framework.
    If the results of the multi-CNN were not concatenated it will be done here."""
    result_tsv = os.path.join(output_dir, 'fold-%i' % fold, 'cnn_classification', selection,
                              '%s_%s_level_prediction.tsv' % (dataset, mode))
    if os.path.exists(result_tsv):
        performance_df = pd.read_csv(result_tsv, sep='\t')

    else:
        concat_multi_cnn_results(output_dir, fold, selection, mode, dataset, num_cnn)
        performance_df = pd.read_csv(result_tsv, sep='\t')

    return performance_df


def soft_voting_to_tsvs(output_dir, fold, selection, mode, dataset='test', num_cnn=None, selection_threshold=None):
    """
    Writes soft voting results in tsv files.

    Args:
        output_dir: (str) path to the output directory.
        fold: (int) Fold number of the cross-validation.
        selection: (str) criterion on which the model is selected (either best_loss or best_acc)
        mode: (str) input used by the network. Chosen from ['patch', 'roi', 'slice'].
        dataset: (str) name of the dataset for which the soft-voting is performed. If different from training or
            validation, the weights of soft voting will be computed on validation accuracies.
        num_cnn: (int) if given load the patch level results of a multi-CNN framework.
        selection_threshold: (float) all patches for which the classification accuracy is below the
            threshold is removed.
    """

    # Choose which dataset is used to compute the weights of soft voting.
    if dataset in ['train', 'validation']:
        validation_dataset = dataset
    else:
        validation_dataset = 'validation'
    test_df = retrieve_sub_level_results(output_dir, fold, selection, mode, dataset, num_cnn)
    validation_df = retrieve_sub_level_results(output_dir, fold, selection, mode, validation_dataset, num_cnn)

    performance_path = os.path.join(output_dir, 'fold-%i' % fold, 'cnn_classification', selection)
    if not os.path.exists(performance_path):
        os.makedirs(performance_path)

    df_final, metrics = soft_voting(test_df, validation_df, mode, selection_threshold=selection_threshold)

    df_final.to_csv(os.path.join(os.path.join(performance_path, '%s_image_level_prediction.tsv' % dataset)),
                    index=False, sep='\t')

    pd.DataFrame(metrics, index=[0]).to_csv(os.path.join(performance_path, '%s_image_level_metrics.tsv' % dataset),
                                            index=False, sep='\t')


def soft_voting(performance_df, validation_df, mode, selection_threshold=None):
    """
    Computes soft voting based on the probabilities in performance_df. Weights are computed based on the accuracies
    of validation_df.

    ref: S. Raschka. Python Machine Learning., 2015

    Args:
        performance_df: (DataFrame) results on patch level of the set on which the combination is made.
        validation_df: (DataFrame) results on patch level of the set used to compute the weights.
        mode: (str) input used by the network. Chosen from ['patch', 'roi', 'slice'].
        selection_threshold: (float) if given, all patches for which the classification accuracy is below the
            threshold is removed.

    Returns:
        df_final (DataFrame) the results on the image level
        results (dict) the metrics on the image level
    """

    # Compute the sub-level accuracies on the validation set:
    validation_df["accurate_prediction"] = validation_df.apply(lambda x: check_prediction(x), axis=1)
    sub_level_accuracies = validation_df.groupby("%s_id" % mode)["accurate_prediction"].sum()
    if selection_threshold is not None:
        sub_level_accuracies[sub_level_accuracies < selection_threshold] = 0
    weight_series = sub_level_accuracies / sub_level_accuracies.sum()

    # Sort to allow weighted average computation
    performance_df.sort_values(['participant_id', 'session_id', '%s_id' % mode], inplace=True)
    weight_series.sort_index(inplace=True)

    # Soft majority vote
    columns = ['participant_id', 'session_id', 'true_label', 'predicted_label']
    df_final = pd.DataFrame(columns=columns)
    for (subject, session), subject_df in performance_df.groupby(['participant_id', 'session_id']):
        y = subject_df["true_label"].unique().item()
        proba0 = np.average(subject_df["proba0"], weights=weight_series)
        proba1 = np.average(subject_df["proba1"], weights=weight_series)
        proba_list = [proba0, proba1]
        y_hat = proba_list.index(max(proba_list))

        row = [[subject, session, y, y_hat]]
        row_df = pd.DataFrame(row, columns=columns)
        df_final = df_final.append(row_df)

    results = evaluate_prediction(df_final.true_label.values.astype(int),
                                  df_final.predicted_label.values.astype(int))

    return df_final, results


def check_prediction(row):
    if row["true_label"] == row["predicted_label"]:
        return 1
    else:
        return 0
