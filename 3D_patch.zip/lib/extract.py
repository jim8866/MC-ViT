import torch
import os
import numpy as np
import nibabel as nib
import matplotlib.pyplot as plt


def extract_patch_55(filepaths, label, patch_size, stride_size, imagepath, nummber=1):
    """
    :param filepaths: nii的数据
    :param patch_size: patch的大小
    :param stride_size: 将以stride进行选取patch_size，此处仅以一个patch做为测试
    :param imagepath:  数据存放位置
    :param nummber:  读取的patch数量，此处仅为1
    :return: 返回获取的数据
    """
    num_patches = 3
    num_list = []
    thick_select = []
    file_list = []
    label_list = []
    stride_size_s = stride_size
    for k in np.arange(len(filepaths)):
    #for k in np.arange(100):
    #for k in np.arange(3):
        filename = os.path.join(imagepath, filepaths[k] + '.nii.gz')
        # print("filename:", filename)
        import sys
        # sys.exit(0)
        img = nib.load(filename)
        ##        print(img.shape)
        data1 = img.get_data()
        print("data1.shape:", data1.shape)
        #data = data1[64: 192, 80:192, 45: 201]
        data = data1[65: 193, 76:195, 45: 200]
        a = os.path.join("./image",  "all.nii.gz")
        nib.Nifti1Image(data, img.affine).to_filename(a)
        
        
        
        print("data.shape:", data.shape)
        #os.exit()
        """
        a = os.path.join("./image",  "all.nii.gz")
        nib.Nifti1Image(data, img.affine).to_filename(a)
        """
        #print("data.shape:", data.shape)
        #os.exit(0)
        """"""
        #x_stride = int(data.shape[0] / 4)
        #y_stride = int(data.shape[1] / 4)
        #z_stride = int(data.shape[2] / 4)
        #print("x_stride:", x_stride, "y_stride:", y_stride, "z_stride:", z_stride)
        x_stride = 24
        y_stride = 21
        z_stride = 33
        x_ = -24
        y_ = -21
        z_ = -33
        count = 0

        for i in np.arange(4):
            #print("k:", k)
            x_ = -24

            if i == 3:
                z_ = 155 - patch_size
            else:
                z_ += z_stride
            #print("===========================================")
            for j in np.arange(4):
                if j == 3:
                    x_ = 128 - patch_size
                else:
                    x_ += x_stride
                # print("x_:", x_)
                #print("===========================================")
                y_ = -21
                for h in np.arange(4):
                    # x_ += x_stride
                    # print("x:", x_)
                    if h == 3:
                        y_ = 119 - patch_size
                    else:
                        y_ += y_stride

                    count += 1

                    print("count: %d, x_begin-x_end:[%d:%d], y_begin-y_end:[%d:%d], z_begin-z_end:[%d:%d]" % (
                    count, x_, x_ + patch_size, y_, y_ + patch_size, z_, z_ + patch_size))

                    thick = data[x_ : x_  + patch_size,
                            y_ : y_ + patch_size,
                            z_: z_ + patch_size]
                    #if count == 4 and k < 3:
                    #    print("count:", count, "k:", k, "thick:", thick[0:20])

                    # print("thick.shape:", thick.shape)
                    thick_select.append(thick)
                    num_list.append(count)
                    label_list.append(label[k])
                    file_list.append(filepaths[k])
                    #print("count:\n", count, "thick:", thick[0:100])
                    a = os.path.join("./image",  str(count) + ".nii.gz")
                    nib.Nifti1Image(data, img.affine).to_filename(a)
        """
        if k == 3:
            os.exit()
        """
        os.exit()
    thick_select = np.array(thick_select)
    num_list = np.array(num_list)
    label_list = np.array(label_list)
    file_list = np.array(file_list)
    print("thick_select.shape:", thick_select.shape)
    print("num_list.shape:", num_list.shape)
    print("label_list.shape:", label_list.shape)
    print("file_list.shape:", file_list.shape)
    #sys.exit(0)
    #print("num_list:", num_list)
    #print("file_list:", file_list)
    thick_select_s = np.array(thick_select)
    label_list_s = np.array(label_list)
    file_list_s = np.array(file_list)
    num_list_s = np.array(num_list)

    return thick_select_s, label_list_s, file_list_s, num_list_s


def extract_patch_50(filepaths, label, patch_size, stride_size, imagepath, nummber=1):
    """
    :param filepaths: nii的数据
    :param patch_size: patch的大小
    :param stride_size: 将以stride进行选取patch_size，此处仅以一个patch做为测试
    :param imagepath:  数据存放位置
    :param nummber:  读取的patch数量，此处仅为1
    :return: 返回获取的数据
    """
    num_patches = 3
    num_list = []
    thick_select = []
    file_list = []
    label_list = []
    stride_size_s = stride_size
    for k in np.arange(len(filepaths)):
    #for k in np.arange(50):
        filename = os.path.join(imagepath, filepaths[k] + '.nii.gz')
        # print("filename:", filename)
        import sys
        # sys.exit(0)
        img = nib.load(filename)
        ##        print(img.shape)
        data1 = img.get_data()
        #print("data1.shape:", data1.shape)
        #data = data1[64: 192, 80:192, 45: 201]
        data = data1[65: 193, 76:195, 45: 200]
        #print("data.shape:", data.shape)
        """
        a = os.path.join("./image",  "all.nii.gz")
        nib.Nifti1Image(data, img.affine).to_filename(a)
        """
        #print("data.shape:", data.shape)
        #os.exit(0)
        """"""
        #x_stride = int(data.shape[0] / 4)
        #y_stride = int(data.shape[1] / 4)
        #z_stride = int(data.shape[2] / 4)
        #print("x_stride:", x_stride, "y_stride:", y_stride, "z_stride:", z_stride)
        x_stride = 26
        y_stride = 23
        z_stride = 35
        x_ = -26
        y_ = -23
        z_ = -35
        count = 0

        for i in np.arange(4):
            #print("k:", k)
            x_ = -26
            z_ += z_stride
            #print("===========================================")
            for j in np.arange(4):
                x_ += x_stride
                # print("x_:", x_)
                #print("===========================================")
                y_ = -23
                for h in np.arange(4):
                    # x_ += x_stride
                    # print("x:", x_)
                    y_ += y_stride

                    count += 1

                    thick = data[x_ : x_  + patch_size,
                            y_ : y_ + patch_size,
                            z_: z_ + patch_size]



                    thick_select.append(thick)
                    num_list.append(count)
                    label_list.append(label[k])
                    file_list.append(filepaths[k])

        """
        if k == 3:
            os.exit()
        """

    thick_select = np.array(thick_select)
    num_list = np.array(num_list)
    label_list = np.array(label_list)
    file_list = np.array(file_list)
    print("thick_select.shape:", thick_select.shape)
    print("num_list.shape:", num_list.shape)
    print("label_list.shape:", label_list.shape)
    print("file_list.shape:", file_list.shape)
    #sys.exit(0)
    #print("num_list:", num_list)
    #print("file_list:", file_list)
    thick_select_s = np.array(thick_select)
    label_list_s = np.array(label_list)
    file_list_s = np.array(file_list)
    num_list_s = np.array(num_list)

    return thick_select_s, label_list_s, file_list_s, num_list_s




"""
#import os
os.exit()

x_ = 40
y_ = 40
z_ = 40
#print("data.shape:", data.shape)
stride_size = stride_size_s
for num_patch in np.arange(num_patches):
    print("stride:", stride_size, num_patch, filename)
    #xData = data[slicesindex - 1:slicesindex + 2, edge:-edge, edge:-edge];
    thick = data[x_ + stride_size: x_+patch_size + stride_size, y_ + stride_size : y_+patch_size + stride_size, z_ + stride_size: z_+patch_size + stride_size]
    #thick = data[120:120 + patch_size, 150:150 + patch_size, 100:100 + patch_size]
    #thick = data[80:80 + patch_size, 155:155 + patch_size, 60:60 + patch_size]
    #thick = data[64: 192, 64 :192, 80: 192]
    #thick = data[64: 192, 80:192, 45: 200]
    #print("thick.shape:", thick.shape)
    #print("thick.shape:", thick.shape)
    thick_select.append(thick)
    num_list.append(num_patch)
    file_list.append(filepaths[k])
    label_list.append(label[k])
    stride_size += 10
    #print("num_list in :", num_list)
"""
"""
if k == 10:
    for dire in np.arange(0,3):

        #data_show = thick[:, :,  i: i+3]
        if dire == 0:
            for i in np.arange(thick.shape[0] - 2):
                data_show = thick[i: i+3, ...]
                data_show = np.transpose(data_show, (1, 2, 0))
                print("data_show.shape::", data_show.shape)
                #plt.subplot(2, 1, 1)
                #plt.
                plt.imshow(data_show)
                plt.axis('off')
                plt.title("image %d"%i)
                #plt.show()
                a = str(dire) + "_" +str(i) + ".png"
                b = os.path.join("./image10", a)
                print("b:", b)
                plt.savefig(b, bbox_inches='tight')
        if dire == 1:
            for i in np.arange(thick.shape[1] - 2):
                xData = thick[:, i:i+3, :]
                data_show = np.transpose(xData, (0, 2, 1))

                print("data_show.shape::", data_show.shape)
                #plt.subplot(2, 1, 1)
                #plt.
                plt.imshow(data_show)
                plt.axis('off')
                plt.title("image %d"%i)
                #plt.show()
                a = str(dire) + "_" +str(i) + ".png"
                b = os.path.join("./image10", a)
                print("b:", b)
                plt.savefig(b, bbox_inches='tight')
        if dire == 2:
            for i in np.arange(thick.shape[2] - 2):
                xData = thick[:, :, i: i+3];
                data_show = xData

                print("data_show.shape::", data_show.shape)
                #plt.subplot(2, 1, 1)
                #plt.
                plt.imshow(data_show)
                plt.axis('off')
                plt.title("image %d"%i)
                #plt.show()
                a = str(dire) + "_" +str(i) + ".png"
                b = os.path.join("./image10", a)
                print("b:", b)
                plt.savefig(b, bbox_inches='tight')


    os.exit(0)
"""




#暂时没有用到
def extract_patches(input_tensor, patch_size, stride_size):
    """Extracts the patches

    This function extracts patches form the preprocesed nifti image. Patch size
    if provieded as input and also the stride size. If stride size is smaller
    than the patch size an overlap exist between consecutive patches. If stride
    size is equal to path size there is no overlap. Otherwise, unprocessed
    zones can exits.

    Args:
        input_tensor: tensor version of the nifti MRI.
        patch_size: size of a single patch.
        stride_size: size of the stride leading to next patch.

    Returns:
        file: multiple tensors saved on the disk, suffixes corresponds to
            indexes of the patches. Same location than input file.
    """


    basedir = os.getcwd()
    image_tensor = torch.load(input_tensor)

    print("patch_size:", patch_size)
    print("stride_size:", stride_size)

    # use classifiers tensor.upfold to crop the patch.
    patches_tensor = image_tensor.unfold(1, patch_size, stride_size).unfold(2, patch_size, stride_size).unfold(3, patch_size, stride_size).contiguous()
    # the dimension of patch_tensor should be [1, patch_num1, patch_num2, patch_num3, patch_size1, patch_size2, patch_size3]
    patches_tensor = patches_tensor.view(-1, patch_size, patch_size, patch_size)

    input_tensor_filename = os.path.basename(input_tensor)
    txt_idx = input_tensor_filename.rfind("_")
    it_filename_prefix = input_tensor_filename[0:txt_idx]
    it_filename_suffix = input_tensor_filename[txt_idx:]

    output_patch = []
    for index_patch in range(patches_tensor.shape[0]):
        extracted_patch = patches_tensor[index_patch, ...].unsqueeze_(0)  # add one dimension
        # save into .pt format
        output_patch.append(
                os.path.join(
                    basedir,
                    it_filename_prefix
                    + '_patchsize-'
                    + str(patch_size)
                    + '_stride-'
                    + str(stride_size)
                    + '_patch-'
                    + str(index_patch)
                    + it_filename_suffix
                )
                )
        torch.save(extracted_patch.clone(), output_patch[index_patch])
        print("extracted_patch:", extracted_patch)
        print("output_patch:", output_patch)

    return output_patch